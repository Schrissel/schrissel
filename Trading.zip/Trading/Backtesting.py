# ============================================================
#  📈 KI-Trading-System – Backtesting Modul
#  ✅ Trefferquote (wie oft lag das Modell richtig?)
#  ✅ Gesamtrendite vs. Buy & Hold
#  ✅ Maximaler Verlust (Drawdown)
#  ✅ Equity-Kurve als Chart
# ============================================================
#
#  WICHTIG: Fuehre zuerst stock_predictor_v3.py aus, damit
#  das Modell trainiert und gespeichert ist!
#
#  Installation (einmalig im Terminal):
#  pip install yfinance pandas_ta xgboost scikit-learn matplotlib joblib
#
# ============================================================

import os
import joblib
import warnings
import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from datetime import datetime, timedelta
from xgboost import XGBClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

# ============================================================
# ⚙️  EINSTELLUNGEN – gleiche wie in stock_predictor_v3.py!
# ============================================================

TICKER              = "SAP.DE"
START_DATE          = "2015-01-01"
ZIEL_RENDITE        = 0.01
VORAUSSCHAU         = 3

STARTKAPITAL        = 1000.0        # Startkapital in Euro
TRANSAKTIONSKOSTEN  = 0.001         # 0.1% pro Trade (typisch Online-Broker)
MINDEST_KONFIDENZ   = 0.55          # Nur kaufen wenn Modell >= 55% sicher

BASIS_ORDNER  = "."
DATEN_ORDNER  = f"{BASIS_ORDNER}/daten"
MODELL_ORDNER = f"{BASIS_ORDNER}/modelle"
LOG_ORDNER    = f"{BASIS_ORDNER}/ergebnisse"

MODELL_PFAD = f"{MODELL_ORDNER}/{TICKER.replace('.', '_')}_modell_v3.pkl"
SCALER_PFAD = f"{MODELL_ORDNER}/{TICKER.replace('.', '_')}_scaler_v3.pkl"

for ordner in [DATEN_ORDNER, MODELL_ORDNER, LOG_ORDNER]:
    os.makedirs(ordner, exist_ok=True)

# ============================================================
# 📊  FEATURES – exakt gleich wie in v3!
# ============================================================

FEATURES = [
    "SMA_20", "SMA_50", "EMA_12",
    "Abstand_SMA20", "Abstand_SMA50", "SMA_Kreuz",
    "RSI", "RSI_Trend", "RSI_Ueberkauft",
    "MACD", "MACD_Signal",
    "BB_Width", "BB_Position", "ATR_norm",
    "Volume_Ratio", "Volume_Trend",
    "Return_1d", "Return_5d", "Return_20d", "Return_60d",
    "Higher_High", "Gap_Up", "Kerze_Groesse",
    "Wochentag", "Monat",
]

# ============================================================
# 📥  DATEN LADEN
# ============================================================

def lade_daten():
    pfad = f"{DATEN_ORDNER}/{TICKER.replace('.', '_')}.csv"
    if not os.path.exists(pfad):
        print("Keine lokalen Daten – lade von Yahoo Finance...")
        heute = datetime.today().strftime("%Y-%m-%d")
        df = yf.download(TICKER, start=START_DATE, end=heute,
                         auto_adjust=True, progress=False)
        df.columns = df.columns.droplevel(1) if isinstance(df.columns, pd.MultiIndex) else df.columns
        df.to_csv(pfad)
    else:
        df = pd.read_csv(pfad, index_col="Date", parse_dates=True)

    print(f"Daten geladen: {len(df)} Tage "
          f"({df.index[0].strftime('%d.%m.%Y')} – {df.index[-1].strftime('%d.%m.%Y')})")
    return df

# ============================================================
# 📊  INDIKATOREN – exakt gleich wie in v3!
# ============================================================

def berechne_indikatoren(df):
    df = df.copy()

    df["SMA_20"]         = ta.sma(df["Close"], length=20)
    df["SMA_50"]         = ta.sma(df["Close"], length=50)
    df["EMA_12"]         = ta.ema(df["Close"], length=12)
    df["Abstand_SMA20"]  = (df["Close"] - df["SMA_20"]) / df["SMA_20"]
    df["Abstand_SMA50"]  = (df["Close"] - df["SMA_50"]) / df["SMA_50"]
    df["SMA_Kreuz"]      = (df["SMA_20"] > df["SMA_50"]).astype(int)

    df["RSI"]            = ta.rsi(df["Close"], length=14)
    df["RSI_Trend"]      = df["RSI"] - df["RSI"].shift(3)
    df["RSI_Ueberkauft"] = np.where(df["RSI"] > 70, 1,
                            np.where(df["RSI"] < 30, -1, 0))

    macd = ta.macd(df["Close"])
    macd_col   = [c for c in macd.columns if c.startswith("MACD_")][0]
    signal_col = [c for c in macd.columns if c.startswith("MACDs_")][0]
    df["MACD"]        = macd[macd_col]
    df["MACD_Signal"] = macd[signal_col]

    bb = ta.bbands(df["Close"], length=20)
    bb_upper = [c for c in bb.columns if c.startswith("BBU")][0]
    bb_lower = [c for c in bb.columns if c.startswith("BBL")][0]
    df["BB_Width"]    = (bb[bb_upper] - bb[bb_lower]) / df["Close"]
    df["BB_Position"] = (df["Close"] - bb[bb_lower]) / (bb[bb_upper] - bb[bb_lower])

    atr = ta.atr(df["High"], df["Low"], df["Close"], length=14)
    df["ATR_norm"]     = atr / df["Close"]

    df["Volume_SMA"]   = ta.sma(df["Volume"], length=20)
    df["Volume_Ratio"] = df["Volume"] / df["Volume_SMA"]
    df["Volume_Trend"] = (df["Volume"] > df["Volume"].shift(1)).astype(int)

    df["Return_1d"]  = df["Close"].pct_change(1)
    df["Return_5d"]  = df["Close"].pct_change(5)
    df["Return_20d"] = df["Close"].pct_change(20)
    df["Return_60d"] = df["Close"].pct_change(60)

    df["Higher_High"]   = (df["High"] > df["High"].shift(1)).astype(int)
    df["Gap_Up"]        = (df["Open"] > df["Close"].shift(1)).astype(int)
    df["Kerze_Groesse"] = (df["High"] - df["Low"]) / df["Close"]

    df["Wochentag"] = df.index.dayofweek
    df["Monat"]     = df.index.month

    df["Target"] = (
        df["Close"].shift(-VORAUSSCHAU) / df["Close"] - 1 > ZIEL_RENDITE
    ).astype(int)

    df.dropna(inplace=True)
    return df

# ============================================================
# 🤖  MODELL LADEN ODER TRAINIEREN
# ============================================================

def lade_oder_trainiere_modell(df):
    if os.path.exists(MODELL_PFAD) and os.path.exists(SCALER_PFAD):
        print(f"\nLade gespeichertes Modell...")
        model  = joblib.load(MODELL_PFAD)
        scaler = joblib.load(SCALER_PFAD)
        return model, scaler

    print("\nKein Modell gefunden – trainiere neu...")
    X      = df[FEATURES]
    y      = df["Target"]
    scaler = StandardScaler()
    X_all  = scaler.fit_transform(X)
    model  = XGBClassifier(
        n_estimators=600, max_depth=4, learning_rate=0.02,
        subsample=0.75, colsample_bytree=0.75, min_child_weight=15,
        gamma=0.1, reg_alpha=0.1, reg_lambda=1.5,
        eval_metric="logloss", random_state=42, verbosity=0, n_jobs=-1
    )
    model.fit(X_all, y)
    joblib.dump(model, MODELL_PFAD)
    joblib.dump(scaler, SCALER_PFAD)
    print("  Modell trainiert & gespeichert!")
    return model, scaler

# ============================================================
# 🔄  BACKTESTING – das Herzstuck
# ============================================================

def run_backtesting(df, model, scaler):
    """
    Simuliert den Handel auf historischen Daten.
    Walk-Forward: 60% Training, 40% Backtest-Zeitraum.
    Kein Lookahead Bias: Modell sieht nie zukuenftige Daten.
    """
    print("\nStarte Backtesting...")

    split_idx   = int(len(df) * 0.60)
    df_train    = df.iloc[:split_idx]
    df_backtest = df.iloc[split_idx:].copy()

    print(f"  Training:  {df_train.index[0].strftime('%d.%m.%Y')} – "
          f"{df_train.index[-1].strftime('%d.%m.%Y')} ({len(df_train)} Tage)")
    print(f"  Backtest:  {df_backtest.index[0].strftime('%d.%m.%Y')} – "
          f"{df_backtest.index[-1].strftime('%d.%m.%Y')} ({len(df_backtest)} Tage)")

    # Modell auf Trainingsdaten neu trainieren (sauber!)
    X_train = scaler.fit_transform(df_train[FEATURES])
    model.fit(X_train, df_train["Target"])

    # Vorhersagen auf Backtest-Daten
    X_backtest  = scaler.transform(df_backtest[FEATURES])
    wahrsch     = model.predict_proba(X_backtest)[:, 1]
    vorhersagen = (wahrsch >= MINDEST_KONFIDENZ).astype(int)

    # Simulation
    kapital       = STARTKAPITAL
    kapital_kurve = [STARTKAPITAL]
    trades        = []
    in_position   = False
    kauf_kurs     = 0.0
    kauf_datum    = None

    for i in range(len(df_backtest) - VORAUSSCHAU):
        datum     = df_backtest.index[i]
        kurs      = df_backtest["Close"].iloc[i]
        signal    = vorhersagen[i]
        wkeit     = wahrsch[i]
        echt_ziel = df_backtest["Target"].iloc[i]

        if signal == 1 and not in_position:
            # KAUFEN
            kosten      = kapital * TRANSAKTIONSKOSTEN
            kauf_kurs   = kurs
            kauf_datum  = datum
            kapital    -= kosten
            in_position = True

        elif in_position:
            # VERKAUFEN nach VORAUSSCHAU Tagen
            exit_idx      = min(i + VORAUSSCHAU - 1, len(df_backtest) - 1)
            verkauf_kurs  = df_backtest["Close"].iloc[exit_idx]
            rendite       = (verkauf_kurs - kauf_kurs) / kauf_kurs
            kosten        = kapital * TRANSAKTIONSKOSTEN
            kapital       = kapital * (1 + rendite) - kosten
            in_position   = False

            trades.append({
                "Kauf_Datum":     kauf_datum.strftime("%d.%m.%Y"),
                "Verkauf_Datum":  df_backtest.index[exit_idx].strftime("%d.%m.%Y"),
                "Kauf_Kurs":      round(kauf_kurs, 2),
                "Verkauf_Kurs":   round(verkauf_kurs, 2),
                "Rendite_%":      round(rendite * 100, 2),
                "Wahrsch_%":      round(wkeit * 100, 1),
                "Richtig":        "JA" if (rendite > 0) == (echt_ziel == 1) else "NEIN",
                "Kapital_danach": round(kapital, 2),
            })

        kapital_kurve.append(kapital)

    # Offene Position am Ende schliessen
    if in_position:
        verkauf_kurs = df_backtest["Close"].iloc[-1]
        rendite = (verkauf_kurs - kauf_kurs) / kauf_kurs
        kapital = kapital * (1 + rendite)
        kapital_kurve.append(kapital)

    return pd.DataFrame(trades), kapital_kurve, df_backtest

# ============================================================
# 📊  KENNZAHLEN BERECHNEN
# ============================================================

def berechne_kennzahlen(trades_df, kapital_kurve, df_backtest):
    endkapital    = kapital_kurve[-1]
    gesamtrendite = (endkapital - STARTKAPITAL) / STARTKAPITAL * 100
    anzahl_trades = len(trades_df)

    if anzahl_trades == 0:
        print("\nKeine Trades im Backtest-Zeitraum!")
        return {}

    richtige     = (trades_df["Richtig"] == "JA").sum()
    trefferquote = richtige / anzahl_trades * 100

    gewinn_trades = trades_df[trades_df["Rendite_%"] > 0]
    verlust_trades = trades_df[trades_df["Rendite_%"] <= 0]
    avg_gewinn    = gewinn_trades["Rendite_%"].mean() if len(gewinn_trades) > 0 else 0
    avg_verlust   = verlust_trades["Rendite_%"].mean() if len(verlust_trades) > 0 else 0

    kurve        = np.array(kapital_kurve)
    peak         = np.maximum.accumulate(kurve)
    drawdown     = (kurve - peak) / peak * 100
    max_drawdown = drawdown.min()

    gesamt_gewinn  = gewinn_trades["Rendite_%"].sum() if len(gewinn_trades) > 0 else 0
    gesamt_verlust = abs(verlust_trades["Rendite_%"].sum()) if len(verlust_trades) > 0 else 1
    profit_factor  = gesamt_gewinn / gesamt_verlust if gesamt_verlust > 0 else 0

    # Buy & Hold Vergleich
    bah_rendite = (df_backtest["Close"].iloc[-1] / df_backtest["Close"].iloc[0] - 1) * 100

    return {
        "Startkapital":      STARTKAPITAL,
        "Endkapital":        round(endkapital, 2),
        "Gesamtrendite_%":   round(gesamtrendite, 2),
        "BuyHold_Rendite_%": round(bah_rendite, 2),
        "Anzahl_Trades":     anzahl_trades,
        "Trefferquote_%":    round(trefferquote, 1),
        "Richtige_Trades":   int(richtige),
        "Falsche_Trades":    int(anzahl_trades - richtige),
        "Avg_Gewinn_%":      round(avg_gewinn, 2),
        "Avg_Verlust_%":     round(avg_verlust, 2),
        "Profit_Factor":     round(profit_factor, 2),
        "Max_Drawdown_%":    round(max_drawdown, 2),
    }

# ============================================================
# 🖨️  ERGEBNISSE AUSGEBEN
# ============================================================

def zeige_ergebnisse(kennzahlen, trades_df):
    if not kennzahlen:
        return

    r  = kennzahlen["Gesamtrendite_%"]
    bh = kennzahlen["BuyHold_Rendite_%"]
    tq = kennzahlen["Trefferquote_%"]
    pf = kennzahlen["Profit_Factor"]

    print("\n" + "=" * 58)
    print(f"  BACKTESTING ERGEBNISSE – {TICKER}")
    print(f"  Startkapital: {STARTKAPITAL:.0f} EUR | Konfidenz >= {MINDEST_KONFIDENZ*100:.0f}%")
    print("=" * 58)

    print(f"\n  KAPITAL")
    print(f"  Startkapital:         {kennzahlen['Startkapital']:>9.2f} EUR")
    print(f"  Endkapital:           {kennzahlen['Endkapital']:>9.2f} EUR")
    print(f"  Rendite Modell:       {r:>+9.2f}%")
    print(f"  Rendite Buy & Hold:   {bh:>+9.2f}%")
    print(f"  Vorteil ggue. B&H:    {r-bh:>+9.2f}%  "
          f"({'BESSER' if r > bh else 'SCHLECHTER'})")
    print(f"  Max. Drawdown:        {kennzahlen['Max_Drawdown_%']:>9.2f}%")

    print(f"\n  TRADES")
    print(f"  Anzahl Trades:        {kennzahlen['Anzahl_Trades']:>9}")
    print(f"  Trefferquote:         {tq:>8.1f}%  "
          f"({'SEHR GUT' if tq >= 60 else 'GUT' if tq >= 55 else 'OK' if tq >= 50 else 'SCHLECHT'})")
    print(f"  Richtige Trades:      {kennzahlen['Richtige_Trades']:>9}")
    print(f"  Falsche Trades:       {kennzahlen['Falsche_Trades']:>9}")
    print(f"  Avg. Gewinn/Trade:    {kennzahlen['Avg_Gewinn_%']:>+9.2f}%")
    print(f"  Avg. Verlust/Trade:   {kennzahlen['Avg_Verlust_%']:>+9.2f}%")
    print(f"  Profit Factor:        {pf:>9.2f}  "
          f"({'SEHR GUT' if pf >= 1.5 else 'OK' if pf >= 1.0 else 'SCHLECHT'})")

    # Die letzten 5 Trades anzeigen
    if len(trades_df) > 0:
        print(f"\n  LETZTE 5 TRADES:")
        print(f"  {'Kauf':>10} {'Verkauf':>10} {'Rendite':>8} {'Richtig':>8}")
        print(f"  {'-'*42}")
        for _, t in trades_df.tail(5).iterrows():
            print(f"  {t['Kauf_Datum']:>10} {t['Verkauf_Datum']:>10} "
                  f"{t['Rendite_%']:>+7.2f}% {t['Richtig']:>8}")

    print("\n" + "=" * 58)
    print("  WICHTIG: Backtest != Zukunft. Immer Papier-Trading zuerst!")
    print("=" * 58)

# ============================================================
# 📈  CHART ERSTELLEN
# ============================================================

def erstelle_chart(kapital_kurve, trades_df, df_backtest):
    fig = plt.figure(figsize=(14, 10))
    fig.suptitle(f"Backtesting – {TICKER} | Startkapital: {STARTKAPITAL:.0f}EUR",
                 fontsize=14, fontweight="bold")
    gs = gridspec.GridSpec(3, 1, figure=fig, hspace=0.45)

    # Chart 1: Kursverlauf mit Trade-Markierungen
    ax1 = fig.add_subplot(gs[0])
    ax1.plot(df_backtest.index, df_backtest["Close"],
             color="gray", linewidth=1, label="Kurs", alpha=0.8)
    ax1.set_title("Kursverlauf mit Trades (blau=Kauf, gruen=Gewinn, rot=Verlust)")
    ax1.set_ylabel("Kurs (EUR)")
    ax1.grid(True, alpha=0.3)

    if len(trades_df) > 0:
        for _, trade in trades_df.iterrows():
            try:
                kauf_dt    = pd.to_datetime(trade["Kauf_Datum"], format="%d.%m.%Y")
                verkauf_dt = pd.to_datetime(trade["Verkauf_Datum"], format="%d.%m.%Y")
                farbe = "green" if trade["Rendite_%"] > 0 else "red"
                ax1.axvline(kauf_dt, color="blue", alpha=0.25, linewidth=0.8)
                ax1.axvline(verkauf_dt, color=farbe, alpha=0.25, linewidth=0.8)
            except:
                pass

    # Chart 2: Equity-Kurve vs. Buy & Hold
    ax2 = fig.add_subplot(gs[1])
    n = min(len(kapital_kurve), len(df_backtest))
    kurve_x = df_backtest.index[:n]
    kurve_y = kapital_kurve[:n]

    bah_faktor  = df_backtest["Close"].iloc[:n] / df_backtest["Close"].iloc[0]
    bah_kapital = STARTKAPITAL * bah_faktor

    ax2.plot(kurve_x, kurve_y,    color="steelblue", linewidth=1.5, label="Modell")
    ax2.plot(kurve_x, bah_kapital, color="orange",   linewidth=1.5,
             linestyle="--", label="Buy & Hold")
    ax2.axhline(STARTKAPITAL, color="gray", linestyle=":", linewidth=1)
    ax2.fill_between(kurve_x, kurve_y, STARTKAPITAL,
                     where=[k >= STARTKAPITAL for k in kurve_y],
                     alpha=0.15, color="green", label="Gewinn")
    ax2.fill_between(kurve_x, kurve_y, STARTKAPITAL,
                     where=[k < STARTKAPITAL for k in kurve_y],
                     alpha=0.15, color="red", label="Verlust")
    ax2.set_title("Equity-Kurve: Modell vs. Buy & Hold")
    ax2.set_ylabel("Kapital (EUR)")
    ax2.legend(loc="upper left", fontsize=8)
    ax2.grid(True, alpha=0.3)

    # Chart 3: Drawdown
    ax3 = fig.add_subplot(gs[2])
    kurve_arr = np.array(kurve_y)
    peak      = np.maximum.accumulate(kurve_arr)
    drawdown  = (kurve_arr - peak) / peak * 100
    ax3.fill_between(kurve_x, drawdown, 0, color="red", alpha=0.5)
    ax3.plot(kurve_x, drawdown, color="darkred", linewidth=0.8)
    ax3.set_title("Drawdown (%)")
    ax3.set_ylabel("Drawdown (%)")
    ax3.set_xlabel("Datum")
    ax3.grid(True, alpha=0.3)

    plt.tight_layout()
    pfad = f"{LOG_ORDNER}/{TICKER.replace('.', '_')}_backtest.png"
    plt.savefig(pfad, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"\nChart gespeichert: {pfad}")
    return pfad

# ============================================================
# 💾  ERGEBNISSE SPEICHERN
# ============================================================

def speichere_ergebnisse(trades_df, kennzahlen):
    if len(trades_df) > 0:
        pfad = f"{LOG_ORDNER}/{TICKER.replace('.', '_')}_backtest_trades.csv"
        trades_df.to_csv(pfad, index=False)
        print(f"Trades gespeichert:     {pfad}")

    pfad = f"{LOG_ORDNER}/{TICKER.replace('.', '_')}_backtest_kennzahlen.csv"
    pd.DataFrame([kennzahlen]).to_csv(pfad, index=False)
    print(f"Kennzahlen gespeichert: {pfad}")

# ============================================================
# ▶️  HAUPTPROGRAMM
# ============================================================

if __name__ == "__main__":
    print("\n" + "=" * 58)
    print(f"  BACKTESTING – {TICKER}")
    print(f"  {datetime.today().strftime('%d.%m.%Y %H:%M:%S')}")
    print("=" * 58 + "\n")

    df_roh        = lade_daten()
    df            = berechne_indikatoren(df_roh)
    model, scaler = lade_oder_trainiere_modell(df)

    trades_df, kapital_kurve, df_backtest = run_backtesting(df, model, scaler)
    kennzahlen = berechne_kennzahlen(trades_df, kapital_kurve, df_backtest)

    zeige_ergebnisse(kennzahlen, trades_df)
    erstelle_chart(kapital_kurve, trades_df, df_backtest)
    speichere_ergebnisse(trades_df, kennzahlen)

    print(f"\nFertig! Alle Dateien in: {LOG_ORDNER}/")
    print(f"   {TICKER.replace('.','_')}_backtest.png")
    print(f"   {TICKER.replace('.','_')}_backtest_trades.csv")
    print(f"   {TICKER.replace('.','_')}_backtest_kennzahlen.csv\n")