# ============================================================
#  📈 Universelles DAX Trading-System v1.0  (mit Makro+Saisonal+Pattern Features)
# ============================================================

import os
import joblib
import warnings
import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from xgboost import XGBClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

# ============================================================
# EINSTELLUNGEN
# ============================================================

START_DATE      = "2018-01-01"
ZIEL_RENDITE    = 0.01
NEU_TRAINIEREN  = True

BASIS_ORDNER  = "chatgpt"
DATEN_ORDNER  = f"{BASIS_ORDNER}/daten"
MODELL_ORDNER = f"{BASIS_ORDNER}/modelle"
LOG_ORDNER    = f"{BASIS_ORDNER}/ergebnisse"

# ============================================================
# ALLE DAX-AKTIEN
# ============================================================

DAX_AKTIEN = {
    "Adidas":               "ADS.DE",
    "Airbus":               "AIR.DE",
    "Allianz":              "ALV.DE",
    "BASF":                 "BAS.DE",
    "Bayer":                "BAYN.DE",
    "Beiersdorf":           "BEI.DE",
    "BMW":                  "BMW.DE",
    "Brenntag":             "BNR.DE",
    "Commerzbank":          "CBK.DE",
    "Continental":          "CON.DE",
    "Covestro":             "1COV.DE",
    "Daimler Truck":        "DTG.DE",
    "Deutsche Bank":        "DBK.DE",
    "Deutsche Boerse":      "DB1.DE",
    "Deutsche Post":        "DHL.DE",
    "Deutsche Telekom":     "DTE.DE",
    "E.ON":                 "EOAN.DE",
    "Fresenius":            "FRE.DE",
    "Hannover Rueck":       "HNR1.DE",
    "Heidelberg Materials": "HEIG.DE",
    "Henkel":               "HENKG.DE",
    "Infineon":             "IFX.DE",
    "Mercedes-Benz":        "MBG.DE",
    "Merck":                "MRK.DE",
    "MTU Aero Engines":     "MTX.DE",
    "Muenchner Rueck":      "MUV2.DE",
    "Porsche AG":           "P911.DE",
    "Porsche SE":           "PAH3.DE",
    "Qiagen":               "QIA.DE",
    "RWE":                  "RWE.DE",
    "SAP":                  "SAP.DE",
    "Sartorius":            "SRT3.DE",
    "Siemens":              "SIE.DE",
    "Siemens Energy":       "ENR.DE",
    "Siemens Healthineers": "SHL.DE",
    "Symrise":              "SY1.DE",
    "Volkswagen":           "VOW3.DE",
    "Vonovia":              "VNA.DE",
    "Zalando":              "ZAL.DE",
    "Rheinmetall":          "RHM.DE",
}

# ============================================================
# FEATURES (erweitert: Makro + Saisonalität + Patterns)
# ============================================================

FEATURES = [
    # Technische Indikatoren
    "SMA_20", "SMA_50", "EMA_12",
    "RSI", "MACD", "MACD_Signal",
    "BB_Width", "ATR",
    "Volume_Ratio",
    "Return_1d", "Return_5d", "Return_20d",

    # Saisonalität
    "Wochentag", "Monat", "Quartal",

    # Kursmuster
    "Higher_High", "Gap_Up", "Abstand_SMA_50",

    # Makro-Kontext
    "DAX_Return_1d", "EURUSD_Return_1d", "OIL_Return_1d",
    "VIX_Close", "VIX_Return_1d"
]

# ============================================================
# SETUP
# ============================================================

for ordner in [DATEN_ORDNER, MODELL_ORDNER, LOG_ORDNER]:
    os.makedirs(ordner, exist_ok=True)

MODELL_PFAD   = f"{MODELL_ORDNER}/DAX_universal_modell.pkl"
SCALER_PFAD   = f"{MODELL_ORDNER}/DAX_universal_scaler.pkl"
SCAN_LOG_PFAD = f"{LOG_ORDNER}/DAX_daily_scan.csv"

# ============================================================
# MAKRO-DATEN LADEN (einmalig)
# ============================================================

def lade_macro_daten(start_date, end_date):
    """
    Lädt Makro-Serien via yfinance und erzeugt robuste Features.
    """
    macro_tickers = {
        "DAX": "^GDAXI",
        "EURUSD": "EURUSD=X",
        "OIL": "CL=F",
        "VIX": "^VIX",
    }

    frames = []
    for key, t in macro_tickers.items():
        df = yf.download(t, start=start_date, end=end_date, auto_adjust=True, progress=False)
        if df.empty:
            continue
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.droplevel(1)

        if "Close" not in df.columns:
            continue

        s = df[["Close"]].rename(columns={"Close": f"{key}_Close"})
        frames.append(s)

    if not frames:
        return None

    macro = pd.concat(frames, axis=1).sort_index()

    # Returns (pct_change)
    if "DAX_Close" in macro.columns:
        macro["DAX_Return_1d"] = macro["DAX_Close"].pct_change(1)
    if "EURUSD_Close" in macro.columns:
        macro["EURUSD_Return_1d"] = macro["EURUSD_Close"].pct_change(1)
    if "OIL_Close" in macro.columns:
        macro["OIL_Return_1d"] = macro["OIL_Close"].pct_change(1)
    if "VIX_Close" in macro.columns:
        macro["VIX_Return_1d"] = macro["VIX_Close"].pct_change(1)

    # Nur die Spalten, die wir wirklich brauchen
    keep = [c for c in [
        "DAX_Return_1d", "EURUSD_Return_1d", "OIL_Return_1d",
        "VIX_Close", "VIX_Return_1d"
    ] if c in macro.columns]

    macro = macro[keep].copy()

    # Handelskalender-Mismatch glätten
    macro = macro.ffill()

    return macro

# ============================================================
# DATEN LADEN & AKTUALISIEREN
# ============================================================

def lade_aktie(name, ticker):
    heute      = datetime.today().strftime("%Y-%m-%d")
    daten_pfad = f"{DATEN_ORDNER}/{ticker.replace('.', '_')}.csv"

    try:
        if os.path.exists(daten_pfad):
            df = pd.read_csv(daten_pfad, index_col="Date", parse_dates=True)
            naechster_tag = (df.index[-1] + timedelta(days=1)).strftime("%Y-%m-%d")
            if naechster_tag <= heute:
                neue_daten = yf.download(ticker, start=naechster_tag, end=heute,
                                         auto_adjust=True, progress=False)
                if not neue_daten.empty:
                    if isinstance(neue_daten.columns, pd.MultiIndex):
                        neue_daten.columns = neue_daten.columns.droplevel(1)
                    df = pd.concat([df, neue_daten])
                    df = df[~df.index.duplicated(keep="last")]
                    df.to_csv(daten_pfad)
        else:
            df = yf.download(ticker, start=START_DATE, end=heute,
                             auto_adjust=True, progress=False)
            if df.empty:
                return None
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.droplevel(1)
            df.to_csv(daten_pfad)

        return df if len(df) > 100 else None

    except Exception:
        return None

# ============================================================
# INDIKATOREN + NEUE FEATURES BERECHNEN
# ============================================================

def berechne_indikatoren(df, macro_df=None):
    try:
        df = df.copy()

        # --- Standard-Indikatoren ---
        df["SMA_20"]  = ta.sma(df["Close"], length=20)
        df["SMA_50"]  = ta.sma(df["Close"], length=50)
        df["EMA_12"]  = ta.ema(df["Close"], length=12)
        df["RSI"]     = ta.rsi(df["Close"], length=14)

        macd = ta.macd(df["Close"])
        macd_col   = [c for c in macd.columns if c.startswith("MACD_")][0]
        signal_col = [c for c in macd.columns if c.startswith("MACDs_")][0]
        df["MACD"]        = macd[macd_col]
        df["MACD_Signal"] = macd[signal_col]

        bb = ta.bbands(df["Close"], length=20)
        bb_upper = [c for c in bb.columns if c.startswith("BBU")][0]
        bb_lower = [c for c in bb.columns if c.startswith("BBL")][0]
        df["BB_Upper"] = bb[bb_upper]
        df["BB_Lower"] = bb[bb_lower]
        df["BB_Width"] = (df["BB_Upper"] - df["BB_Lower"]) / df["Close"]

        df["ATR"]          = ta.atr(df["High"], df["Low"], df["Close"], length=14)
        df["Volume_SMA"]   = ta.sma(df["Volume"], length=20)
        df["Volume_Ratio"] = df["Volume"] / df["Volume_SMA"]
        df["Return_1d"]    = df["Close"].pct_change(1)
        df["Return_5d"]    = df["Close"].pct_change(5)
        df["Return_20d"]   = df["Close"].pct_change(20)

        # --- Saisonalität ---
        df["Wochentag"] = df.index.dayofweek
        df["Monat"]     = df.index.month
        df["Quartal"]   = df.index.quarter

        # --- Kursmuster ---
        df["Higher_High"]     = (df["High"] > df["High"].shift(1)).astype(int)
        df["Gap_Up"]          = (df["Open"] > df["Close"].shift(1)).astype(int)
        df["Abstand_SMA_50"]  = (df["Close"] - df["SMA_50"]) / df["SMA_50"]

        # --- Makro-Kontext (Merge auf Datum) ---
        if macro_df is not None and not macro_df.empty:
            df = df.join(macro_df, how="left")
            # Falls es mal Lücken gibt:
            df[macro_df.columns] = df[macro_df.columns].ffill()

        # --- Target ---
        df["Target"] = (df["Close"].shift(-1) / df["Close"] - 1 > ZIEL_RENDITE).astype(int)

        # --- Cleanup ---
        df.dropna(inplace=True)
        return df if len(df) > 50 else None

    except Exception:
        return None

# ============================================================
# UNIVERSELLES MODELL TRAINIEREN ODER LADEN
# ============================================================

def trainiere_oder_lade_modell(alle_daten):
    modell_existiert = os.path.exists(MODELL_PFAD) and os.path.exists(SCALER_PFAD)

    if modell_existiert and not NEU_TRAINIEREN:
        print("\n📦 Lade universelles DAX-Modell...")
        model  = joblib.load(MODELL_PFAD)
        scaler = joblib.load(SCALER_PFAD)
        print("✅ Modell geladen!")
        return model, scaler

    print("\n🔗 Kombiniere Daten aller DAX-Aktien...")
    kombiniert = pd.concat(alle_daten, ignore_index=True)
    kombiniert.dropna(subset=FEATURES + ["Target"], inplace=True)

    print(f"   Gesamtdatensatz: {len(kombiniert):,} Handelstage aus {len(alle_daten)} Aktien")
    print(f"   Kaufsignale:     {kombiniert['Target'].sum():,} ({kombiniert['Target'].mean()*100:.1f}%)")
    print(f"   Kein Signal:     {(kombiniert['Target']==0).sum():,} ({(1-kombiniert['Target'].mean())*100:.1f}%)")

    X = kombiniert[FEATURES]
    y = kombiniert["Target"]

    print("\n🤖 Trainiere universelles XGBoost-Modell...")
    tscv   = TimeSeriesSplit(n_splits=5)
    scaler = StandardScaler()
    alle_predictions, alle_true = [], []

    for fold, (train_idx, test_idx) in enumerate(tscv.split(X)):
        X_train = scaler.fit_transform(X.iloc[train_idx])
        X_test  = scaler.transform(X.iloc[test_idx])
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        model = XGBClassifier(
            n_estimators=500,
            max_depth=5,
            learning_rate=0.03,
            subsample=0.8,
            colsample_bytree=0.8,
            min_child_weight=10,
            eval_metric="logloss",
            random_state=42,
            verbosity=0
        )
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        alle_predictions.extend(preds)
        alle_true.extend(y_test)
        print(f"   Fold {fold+1}/5: Accuracy = {accuracy_score(y_test, preds)*100:.1f}%")

    gesamt_acc = accuracy_score(alle_true, alle_predictions)
    print(f"\n🏆 Gesamt-Accuracy: {gesamt_acc*100:.1f}%")
    print(classification_report(alle_true, alle_predictions,
                                 target_names=["Kein Signal", "Kaufsignal"]))

    X_all = scaler.fit_transform(X)
    model.fit(X_all, y)

    joblib.dump(model, MODELL_PFAD)
    joblib.dump(scaler, SCALER_PFAD)
    print(f"💾 Universelles Modell gespeichert: {MODELL_PFAD}")

    importances = pd.Series(model.feature_importances_, index=FEATURES).sort_values()
    plt.figure(figsize=(10, 6))
    importances.plot(kind="barh", color="steelblue")
    plt.title("Feature Importance - Universelles DAX-Modell", fontsize=14)
    plt.xlabel("Wichtigkeit")
    plt.tight_layout()
    chart_pfad = f"{LOG_ORDNER}/DAX_feature_importance.png"
    plt.savefig(chart_pfad, dpi=150)
    plt.close()
    print(f"📊 Feature-Chart gespeichert: {chart_pfad}")

    return model, scaler

# ============================================================
# ALLE DAX-AKTIEN SCANNEN
# ============================================================

def scanne_alle_aktien(aktien_dfs, model, scaler):
    heute      = datetime.today().strftime("%d.%m.%Y")
    ergebnisse = []

    print(f"\n🔍 Scanne alle DAX-Aktien...")

    for name, df in aktien_dfs.items():
        try:
            letzter   = df[FEATURES].iloc[[-1]]
            scaled    = scaler.transform(letzter)
            signal    = model.predict(scaled)[0]
            wkeit     = model.predict_proba(scaled)[0][1]
            kurs      = df["Close"].iloc[-1]
            rsi       = df["RSI"].iloc[-1]
            macd      = df["MACD"].iloc[-1]
            vol_ratio = df["Volume_Ratio"].iloc[-1]
            ret_1d    = df["Return_1d"].iloc[-1] * 100

            ergebnisse.append({
                "Aktie":              name,
                "Ticker":             DAX_AKTIEN[name],
                "Kurs (EUR)":         round(kurs, 2),
                "Signal":             "KAUFEN" if signal == 1 else "NICHT KAUFEN",
                "Wahrscheinlichkeit": round(wkeit * 100, 1),
                "RSI":                round(rsi, 1),
                "MACD":               round(macd, 4),
                "Volumen-Ratio":      round(vol_ratio, 2),
                "Rendite gestern %":  round(ret_1d, 2),
            })
        except Exception:
            continue

    df_ergebnis = pd.DataFrame(ergebnisse)
    df_ergebnis = df_ergebnis.sort_values("Wahrscheinlichkeit", ascending=False)
    return df_ergebnis, heute

# ============================================================
# ERGEBNISSE ANZEIGEN & SPEICHERN
# ============================================================

def zeige_ergebnisse(df_ergebnis, heute):
    kaufsignale   = df_ergebnis[df_ergebnis["Signal"] == "KAUFEN"]
    keine_signale = df_ergebnis[df_ergebnis["Signal"] == "NICHT KAUFEN"]

    print("\n" + "="*65)
    print(f"  DAX TAGES-SCAN – {heute}")
    print(f"  Kaufsignale: {len(kaufsignale)} | Kein Signal: {len(keine_signale)}")
    print("="*65)

    if len(kaufsignale) > 0:
        print("\n🟢 KAUFSIGNALE (sortiert nach Wahrscheinlichkeit):")
        print("-"*65)
        for _, row in kaufsignale.iterrows():
            print(f"  {row['Aktie']:<25} ({row['Ticker']:<10})")
            print(f"    Kurs: {row['Kurs (EUR)']:>8.2f} EUR  |  "
                  f"Wahrscheinlichkeit: {row['Wahrscheinlichkeit']:>5.1f}%")
            print(f"    RSI:  {row['RSI']:>5.1f}         |  "
                  f"Gestern: {row['Rendite gestern %']:>+.2f}%")
            print()
    else:
        print("\n  Heute keine Kaufsignale im DAX.")

    print("\n🔴 KEIN SIGNAL (Top 5 knappste Entscheidungen):")
    print("-"*65)
    for _, row in keine_signale.head(5).iterrows():
        print(f"  {row['Aktie']:<25} Wahrscheinlichkeit: {row['Wahrscheinlichkeit']:>5.1f}%")

    print("\n" + "="*65)
    print("  ⚠️  Kein Finanzrat – nur zum Lernen & Papier-Trading!")
    print("="*65)

    df_ergebnis["Datum"] = heute
    if os.path.exists(SCAN_LOG_PFAD):
        log = pd.read_csv(SCAN_LOG_PFAD)
        if heute not in log["Datum"].values:
            log = pd.concat([log, df_ergebnis], ignore_index=True)
            log.to_csv(SCAN_LOG_PFAD, index=False)
    else:
        df_ergebnis.to_csv(SCAN_LOG_PFAD, index=False)

    print(f"\n📝 Scan gespeichert: {SCAN_LOG_PFAD}")

# ============================================================
# HAUPTPROGRAMM
# ============================================================

if __name__ == "__main__":
    print("\n" + "="*65)
    print("  📈 Universelles DAX Trading-System gestartet")
    print(f"  {datetime.today().strftime('%d.%m.%Y %H:%M:%S')}")
    print("="*65)

    heute_iso = datetime.today().strftime("%Y-%m-%d")

    print("\n🌍 Lade Makro-Daten (DAX, EURUSD, Öl, VIX)...")
    macro_df = lade_macro_daten(START_DATE, heute_iso)
    if macro_df is None or macro_df.empty:
        print("   ⚠️  Makro-Daten konnten nicht geladen werden – System läuft ohne Makro-Features.")
        macro_df = None
    else:
        print(f"   ✅ Makro-Daten geladen: {len(macro_df)} Tage")

    print(f"\n📥 Lade Daten fuer {len(DAX_AKTIEN)} DAX-Aktien...")
    print("   (Erstmalig kann das 2-5 Minuten dauern)\n")

    aktien_dfs   = {}
    training_dfs = []
    fehler       = []

    for name, ticker in DAX_AKTIEN.items():
        df_roh = lade_aktie(name, ticker)
        if df_roh is None:
            fehler.append(name)
            continue

        df_ind = berechne_indikatoren(df_roh, macro_df=macro_df)
        if df_ind is None:
            fehler.append(name)
            continue

        aktien_dfs[name] = df_ind
        training_dfs.append(df_ind)
        print(f"   ✅ {name:<25} ({ticker}) – {len(df_ind)} Tage")

    if fehler:
        print(f"\n   ⚠️  Nicht geladen: {', '.join(fehler)}")

    print(f"\n✅ {len(aktien_dfs)} von {len(DAX_AKTIEN)} Aktien erfolgreich geladen!")

    model, scaler = trainiere_oder_lade_modell(training_dfs)
    df_ergebnis, heute = scanne_alle_aktien(aktien_dfs, model, scaler)
    zeige_ergebnisse(df_ergebnis, heute)

    print("\n✅ Fertig! Ordnerstruktur:")
    print(f"   📁 daten/      → {len(aktien_dfs)} CSV-Dateien")
    print(f"   📁 modelle/    → DAX_universal_modell.pkl")
    print(f"   📁 ergebnisse/ → DAX_daily_scan.csv")