# ============================================================
#  📈 KI-Trading-System – Single Stock v3.0
#  ✅ Mehr Features (25 statt 12)
#  ✅ Bessere Hyperparameter + Regularisierung
#  ✅ Verbesserte Zielvariable (3-Tage Vorausschau)
#  ✅ Dreistufiger Konfidenz-Filter
#  ✅ Overfitting-Warnung eingebaut
# ============================================================
#
#  Installation (einmalig im Terminal):
#  pip install yfinance pandas_ta xgboost scikit-learn matplotlib joblib
#
# ============================================================

import os
import joblib
import warnings
import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from xgboost import XGBClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

# ============================================================
# ⚙️  EINSTELLUNGEN
# ============================================================

TICKER          = "SAP.DE"
START_DATE      = "2015-01-01"    # Mehr Daten = besseres Modell (war 2018)
ZIEL_RENDITE    = 0.01
VORAUSSCHAU     = 3               # NEU: 3 Tage vorausschauen statt 1
NEU_TRAINIEREN  = True

# Konfidenz-Filter
SCHWELLE_STARK   = 0.65           # >= 65% = starkes Signal
SCHWELLE_SCHWACH = 0.55           # >= 55% = schwaches Signal

BASIS_ORDNER = "."
DATEN_ORDNER = f"{BASIS_ORDNER}/daten"
MODELL_ORDNER = f"{BASIS_ORDNER}/modelle"
LOG_ORDNER = f"{BASIS_ORDNER}/ergebnisse"

for ordner in [DATEN_ORDNER, MODELL_ORDNER, LOG_ORDNER]:
    os.makedirs(ordner, exist_ok=True)

DATEN_PFAD  = f"{DATEN_ORDNER}/{TICKER.replace('.', '_')}.csv"
MODELL_PFAD = f"{MODELL_ORDNER}/{TICKER.replace('.', '_')}_modell_v3.pkl"
SCALER_PFAD = f"{MODELL_ORDNER}/{TICKER.replace('.', '_')}_scaler_v3.pkl"
LOG_PFAD    = f"{LOG_ORDNER}/{TICKER.replace('.', '_')}_signale.csv"

# ============================================================
# 📊  FEATURE-LISTE (25 Features statt 12)
# ============================================================

FEATURES = [
    # Trend (6)
    "SMA_20", "SMA_50", "EMA_12",
    "Abstand_SMA20",        # Abstand Kurs zu SMA20 (normalisiert)
    "Abstand_SMA50",        # Abstand Kurs zu SMA50 (normalisiert)
    "SMA_Kreuz",            # Goldenes Kreuz: SMA20 > SMA50?

    # Momentum (5)
    "RSI",
    "RSI_Trend",            # Steigt oder faellt der RSI?
    "RSI_Ueberkauft",       # +1 ueberkauft, -1 ueberverkauft, 0 normal
    "MACD",
    "MACD_Signal",

    # Volatilitaet (3)
    "BB_Width",
    "BB_Position",          # Position im Bollinger Band (0=unten, 1=oben)
    "ATR_norm",             # ATR normalisiert

    # Volumen (2)
    "Volume_Ratio",
    "Volume_Trend",         # Steigt Volumen?

    # Renditen (4)
    "Return_1d",
    "Return_5d",
    "Return_20d",
    "Return_60d",           # Quartalsrendite

    # Kurs-Muster (3)
    "Higher_High",          # Neues Tageshoch?
    "Gap_Up",               # Aufwaertsluecke?
    "Kerze_Groesse",        # Kerzengroesse relativ zum Kurs

    # Saisonalitaet (2)
    "Wochentag",
    "Monat",
]

# ============================================================
# 📥  SCHRITT 1: Daten laden
# ============================================================

def lade_daten(ticker, start_date):
    heute = datetime.today().strftime("%Y-%m-%d")

    if os.path.exists(DATEN_PFAD):
        print(f"Lokale Daten gefunden: {DATEN_PFAD}")
        df = pd.read_csv(DATEN_PFAD, index_col="Date", parse_dates=True)
        print(f"   Letzte Daten: {df.index[-1].strftime('%Y-%m-%d')}")
        naechster = (df.index[-1] + timedelta(days=1)).strftime("%Y-%m-%d")
        if naechster <= heute:
            print(f"Lade neue Daten: {naechster} bis {heute}")
            neue = yf.download(ticker, start=naechster, end=heute,
                               auto_adjust=True, progress=False)
            if not neue.empty:
                neue.columns = neue.columns.droplevel(1) if isinstance(neue.columns, pd.MultiIndex) else neue.columns
                df = pd.concat([df, neue])
                df = df[~df.index.duplicated(keep="last")]
                df.to_csv(DATEN_PFAD)
                print(f"  {len(neue)} neue Tage gespeichert!")
            else:
                print("  Keine neuen Daten (Boerse heute geschlossen?).")
        else:
            print("  Daten bereits aktuell!")
    else:
        print(f"Lade alle Daten von Yahoo Finance...")
        df = yf.download(ticker, start=start_date, end=heute,
                         auto_adjust=True, progress=False)
        df.columns = df.columns.droplevel(1) if isinstance(df.columns, pd.MultiIndex) else df.columns
        df.to_csv(DATEN_PFAD)
        print(f"  {len(df)} Handelstage gespeichert!")

    return df

# ============================================================
# 📊  SCHRITT 2: Indikatoren berechnen
# ============================================================

def berechne_indikatoren(df):
    print(f"\nBerechne {len(FEATURES)} Features...")
    df = df.copy()

    # Trend
    df["SMA_20"]        = ta.sma(df["Close"], length=20)
    df["SMA_50"]        = ta.sma(df["Close"], length=50)
    df["EMA_12"]        = ta.ema(df["Close"], length=12)
    df["Abstand_SMA20"] = (df["Close"] - df["SMA_20"]) / df["SMA_20"]
    df["Abstand_SMA50"] = (df["Close"] - df["SMA_50"]) / df["SMA_50"]
    df["SMA_Kreuz"]     = (df["SMA_20"] > df["SMA_50"]).astype(int)

    # Momentum
    df["RSI"]           = ta.rsi(df["Close"], length=14)
    df["RSI_Trend"]     = df["RSI"] - df["RSI"].shift(3)
    df["RSI_Ueberkauft"] = np.where(df["RSI"] > 70, 1,
                            np.where(df["RSI"] < 30, -1, 0))

    macd = ta.macd(df["Close"])
    macd_col   = [c for c in macd.columns if c.startswith("MACD_")][0]
    signal_col = [c for c in macd.columns if c.startswith("MACDs_")][0]
    df["MACD"]        = macd[macd_col]
    df["MACD_Signal"] = macd[signal_col]

    # Volatilitaet
    bb = ta.bbands(df["Close"], length=20)
    bb_upper = [c for c in bb.columns if c.startswith("BBU")][0]
    bb_lower = [c for c in bb.columns if c.startswith("BBL")][0]
    df["BB_Width"]    = (bb[bb_upper] - bb[bb_lower]) / df["Close"]
    df["BB_Position"] = (df["Close"] - bb[bb_lower]) / (bb[bb_upper] - bb[bb_lower])

    atr = ta.atr(df["High"], df["Low"], df["Close"], length=14)
    df["ATR_norm"] = atr / df["Close"]

    # Volumen
    df["Volume_SMA"]   = ta.sma(df["Volume"], length=20)
    df["Volume_Ratio"] = df["Volume"] / df["Volume_SMA"]
    df["Volume_Trend"] = (df["Volume"] > df["Volume"].shift(1)).astype(int)

    # Renditen
    df["Return_1d"]  = df["Close"].pct_change(1)
    df["Return_5d"]  = df["Close"].pct_change(5)
    df["Return_20d"] = df["Close"].pct_change(20)
    df["Return_60d"] = df["Close"].pct_change(60)

    # Kurs-Muster
    df["Higher_High"]   = (df["High"] > df["High"].shift(1)).astype(int)
    df["Gap_Up"]        = (df["Open"] > df["Close"].shift(1)).astype(int)
    df["Kerze_Groesse"] = (df["High"] - df["Low"]) / df["Close"]

    # Saisonalitaet
    df["Wochentag"] = df.index.dayofweek
    df["Monat"]     = df.index.month

    # Zielvariable: Steigt Aktie in VORAUSSCHAU Tagen um > ZIEL_RENDITE?
    df["Target"] = (
        df["Close"].shift(-VORAUSSCHAU) / df["Close"] - 1 > ZIEL_RENDITE
    ).astype(int)

    df.dropna(inplace=True)
    print(f"  {len(FEATURES)} Features berechnet! ({len(df)} Handelstage verfuegbar)")
    return df

# ============================================================
# 🤖  SCHRITT 3: Modell trainieren
# ============================================================

def trainiere_oder_lade_modell(df):
    modell_existiert = os.path.exists(MODELL_PFAD) and os.path.exists(SCALER_PFAD)

    if modell_existiert and not NEU_TRAINIEREN:
        print("\nLade gespeichertes Modell v3...")
        model  = joblib.load(MODELL_PFAD)
        scaler = joblib.load(SCALER_PFAD)
        print(f"  Modell geladen: {MODELL_PFAD}")
        return model, scaler

    print(f"\nTrainiere XGBoost v3 (Vorausschau: {VORAUSSCHAU} Tage, {len(FEATURES)} Features)...\n")

    X = df[FEATURES]
    y = df["Target"]

    tscv   = TimeSeriesSplit(n_splits=7)   # war 5, jetzt 7 Folds
    scaler = StandardScaler()
    alle_preds, alle_true = [], []

    for fold, (train_idx, test_idx) in enumerate(tscv.split(X)):
        X_train = scaler.fit_transform(X.iloc[train_idx])
        X_test  = scaler.transform(X.iloc[test_idx])
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        model = XGBClassifier(
            n_estimators=600,       # war 200
            max_depth=4,
            learning_rate=0.02,     # war 0.05 – langsamer = robuster
            subsample=0.75,
            colsample_bytree=0.75,
            min_child_weight=15,    # Overfitting-Schutz
            gamma=0.1,              # NEU: bestraft unnoetige Splits
            reg_alpha=0.1,          # NEU: L1-Regularisierung
            reg_lambda=1.5,         # NEU: L2-Regularisierung
            eval_metric="logloss",
            random_state=42,
            verbosity=0,
            n_jobs=-1
        )

        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        alle_preds.extend(preds)
        alle_true.extend(y_test)

        print(f"   Fold {fold+1}/7: Accuracy = {accuracy_score(y_test, preds)*100:.1f}%")

    gesamt_acc = accuracy_score(alle_true, alle_preds)
    print(f"\nGesamt-Accuracy: {gesamt_acc*100:.1f}%")
    print(classification_report(alle_true, alle_preds,
                                target_names=["Kein Signal", "Kaufsignal"]))

    if gesamt_acc > 0.80:
        print("WARNUNG: Accuracy ueber 80% – moegliches Overfitting!")
        print("  Tipp: Erhoehe min_child_weight oder reduziere n_estimators.\n")

    # Finales Modell auf allen Daten
    X_all = scaler.fit_transform(X)
    model.fit(X_all, y)

    joblib.dump(model, MODELL_PFAD)
    joblib.dump(scaler, SCALER_PFAD)
    print(f"Modell gespeichert: {MODELL_PFAD}")

    # Feature Importance
    importances = pd.Series(model.feature_importances_, index=FEATURES).sort_values()
    plt.figure(figsize=(10, 8))
    importances.plot(kind="barh", color="steelblue")
    plt.title(f"Feature Importance v3 - {TICKER}", fontsize=14)
    plt.xlabel("Wichtigkeit")
    plt.tight_layout()
    plt.savefig(f"{LOG_ORDNER}/{TICKER.replace('.','_')}_features_v3.png", dpi=150)
    plt.close()
    print("Feature-Chart gespeichert!\n")

    return model, scaler

# ============================================================
# 🔮  SCHRITT 4: Signal generieren
# ============================================================

def signal_staerke(wkeit):
    if wkeit >= SCHWELLE_STARK:
        return "STARK KAUFEN",   "[GRUEN]"
    elif wkeit >= SCHWELLE_SCHWACH:
        return "SCHWACH KAUFEN", "[GELB]"
    else:
        return "NICHT KAUFEN",   "[ROT]"


def generiere_signal(df, model, scaler):
    letzter        = df[FEATURES].iloc[[-1]]
    letzter_scaled = scaler.transform(letzter)

    wkeit              = model.predict_proba(letzter_scaled)[0][1]
    signal_text, emoji = signal_staerke(wkeit)

    kurs   = df["Close"].iloc[-1]
    datum  = df.index[-1].strftime("%d.%m.%Y")
    rsi    = df["RSI"].iloc[-1]
    macd   = df["MACD"].iloc[-1]
    vol    = df["Volume_Ratio"].iloc[-1]
    sma_kr = df["SMA_Kreuz"].iloc[-1]
    bb_pos = df["BB_Position"].iloc[-1]
    ret_5d = df["Return_5d"].iloc[-1] * 100

    print("\n" + "=" * 58)
    print(f"  TRADING SIGNAL v3 - {TICKER} - {datum}")
    print("=" * 58)
    print(f"  Letzter Kurs:        {kurs:.2f} EUR")
    print(f"  Signal ({VORAUSSCHAU} Tage):    {emoji} {signal_text}")
    print(f"  Wahrscheinlichkeit:  {wkeit*100:.1f}%")
    print("-" * 58)
    print(f"  RSI (14):            {rsi:.1f}  "
          f"{'UEBERKAUFT' if rsi > 70 else 'UEBERVERKAUFT' if rsi < 30 else 'NORMAL'}")
    print(f"  MACD:                {macd:.4f}  "
          f"{'positiv' if macd > 0 else 'negativ'}")
    print(f"  Goldenes Kreuz:      {'JA' if sma_kr == 1 else 'NEIN'}")
    print(f"  BB Position:         {bb_pos:.2f}  "
          f"{'oben' if bb_pos > 0.8 else 'unten' if bb_pos < 0.2 else 'mitte'}")
    print(f"  Volumen-Ratio:       {vol:.2f}x")
    print(f"  Rendite (5 Tage):    {ret_5d:+.2f}%")
    print("=" * 58)
    print(f"  WICHTIG: Kein Finanzrat - Vorausschau: {VORAUSSCHAU} Tage")
    print("=" * 58)

    return signal_text, wkeit, kurs, datum

# ============================================================
# 📝  SCHRITT 5: Signal protokollieren
# ============================================================

def protokolliere_signal(datum, kurs, signal, wkeit):
    eintrag = pd.DataFrame([{
        "Datum":              datum,
        "Kurs":               round(kurs, 2),
        "Signal":             signal,
        "Wahrscheinlichkeit": round(wkeit * 100, 1),
        "Vorausschau_Tage":   VORAUSSCHAU,
        "Ergebnis":           ""
    }])

    if os.path.exists(LOG_PFAD):
        log = pd.read_csv(LOG_PFAD)
        if datum not in log["Datum"].values:
            log = pd.concat([log, eintrag], ignore_index=True)
            log.to_csv(LOG_PFAD, index=False)
            print(f"\nSignal protokolliert: {LOG_PFAD}")
        else:
            print(f"\nSignal fuer {datum} bereits gespeichert.")
    else:
        eintrag.to_csv(LOG_PFAD, index=False)
        print(f"\nNeues Protokoll erstellt: {LOG_PFAD}")

# ============================================================
# ▶️  HAUPTPROGRAMM
# ============================================================

if __name__ == "__main__":
    print("\n" + "=" * 58)
    print(f"  KI-Trading-System v3 - {TICKER}")
    print(f"  {datetime.today().strftime('%d.%m.%Y %H:%M:%S')}")
    print("=" * 58 + "\n")

    df            = lade_daten(TICKER, START_DATE)
    df            = berechne_indikatoren(df)
    model, scaler = trainiere_oder_lade_modell(df)
    signal, wkeit, kurs, datum = generiere_signal(df, model, scaler)
    protokolliere_signal(datum, kurs, signal, wkeit)

    print(f"\nFertig!")
    print(f"   daten/      - {TICKER.replace('.','_')}.csv")
    print(f"   modelle/    - {TICKER.replace('.','_')}_modell_v3.pkl")
    print(f"   ergebnisse/ - {TICKER.replace('.','_')}_signale.csv\n")
