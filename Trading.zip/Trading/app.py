# ============================================================
#  📈 KI-Trading-System – Web UI Backend  (Modell v4)
#  Flask-Server der die UI mit Daten versorgt
#
#  Installation (einmalig):
#  pip install flask yfinance pandas_ta xgboost lightgbm
#              scikit-learn matplotlib joblib optuna
#
#  Starten:
#  python app.py
#  Dann im Browser: http://localhost:5000
# ============================================================

import os
import io
import json
import base64
import joblib
import warnings
import threading
import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
import matplotlib
matplotlib.use("Agg")   # Kein Display nötig
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from flask import Flask, jsonify, request, send_from_directory
from datetime import datetime, timedelta
from xgboost import XGBClassifier
from sklearn.model_selection import TimeSeriesSplit, StratifiedKFold
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.feature_selection import SelectFromModel
try:
    import lightgbm as lgb
    LGBM_VERFUEGBAR = True
except ImportError:
    LGBM_VERFUEGBAR = False
try:
    import optuna
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    OPTUNA_VERFUEGBAR = True
except ImportError:
    OPTUNA_VERFUEGBAR = False
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

warnings.filterwarnings("ignore")

app = Flask(__name__, static_folder=os.path.dirname(os.path.abspath(__file__)), static_url_path="")

# ── Numpy-Typen JSON-kompatibel machen ──
# Behebt: "Object of type float32 is not JSON serializable"
class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        return super().default(obj)

app.json_encoder = NumpyEncoder

# ============================================================
# ⚙️  GLOBALE EINSTELLUNGEN
# ============================================================

BASIS_ORDNER  = os.path.dirname(os.path.abspath(__file__))
DATEN_ORDNER  = os.path.join(BASIS_ORDNER, "daten")
MODELL_ORDNER = os.path.join(BASIS_ORDNER, "modelle")
LOG_ORDNER    = os.path.join(BASIS_ORDNER, "ergebnisse")

for ordner in [DATEN_ORDNER, MODELL_ORDNER, LOG_ORDNER]:
    os.makedirs(ordner, exist_ok=True)

START_DATE   = "2015-01-01"
MODELL_VERSION = "v4"   # v4: RobustScaler + 38 Features + Ensemble + Optuna

FEATURES = [
    # Trend
    "SMA_20", "SMA_50", "EMA_12", "EMA_26",
    "Abstand_SMA20", "Abstand_SMA50", "Abstand_SMA200", "SMA_Kreuz",
    # Momentum
    "RSI", "RSI_Trend", "RSI_Ueberkauft",
    "MACD", "MACD_Signal", "MACD_Hist",
    "Stoch_K", "Stoch_D",
    # Volatilität
    "BB_Width", "BB_Position", "ATR_norm",
    "Volatilitaet_20", "Volatilitaet_Regime",
    # Volumen
    "Volume_Ratio", "Volume_Trend", "OBV_Trend",
    # Renditen
    "Return_1d", "Return_5d", "Return_20d", "Return_60d",
    "Return_1d_pos", "Rendite_Konsistenz",
    # Kurs-Muster
    "Higher_High", "Lower_Low", "Gap_Up", "Kerze_Groesse", "Doji",
    # Saisonalität
    "Wochentag", "Monat", "Quartal",
    # Trendfilter
    "Ueber_SMA200", "Trend_Staerke",
]

# Fortschritt für lange laufende Tasks
task_status = {}

# ============================================================
# 🛠️  HILFSFUNKTIONEN
# ============================================================

def lade_daten(ticker):
    heute = datetime.today().strftime("%Y-%m-%d")
    pfad  = f"{DATEN_ORDNER}/{ticker.replace('.', '_')}.csv"

    if os.path.exists(pfad):
        df = pd.read_csv(pfad, index_col="Date", parse_dates=True)
        naechster = (df.index[-1] + timedelta(days=1)).strftime("%Y-%m-%d")
        if naechster <= heute:
            neue = yf.download(ticker, start=naechster, end=heute,
                               auto_adjust=True, progress=False)
            if not neue.empty:
                neue.columns = neue.columns.droplevel(1) if isinstance(neue.columns, pd.MultiIndex) else neue.columns
                df = pd.concat([df, neue])
                df = df[~df.index.duplicated(keep="last")]
                df.to_csv(pfad)
    else:
        df = yf.download(ticker, start=START_DATE, end=heute,
                         auto_adjust=True, progress=False)
        if df.empty:
            return None
        df.columns = df.columns.droplevel(1) if isinstance(df.columns, pd.MultiIndex) else df.columns
        df.to_csv(pfad)

    return df if len(df) > 100 else None


def berechne_indikatoren(df, vorausschau=3, ziel_rendite=0.01):
    """
    v4: 38 Features – Trend, Momentum, Volatilität, Volumen, Saisonalität, Trendfilter
    """
    df = df.copy()

    # ── Gleitende Durchschnitte & Trend ──
    df["SMA_20"]        = ta.sma(df["Close"], length=20)
    df["SMA_50"]        = ta.sma(df["Close"], length=50)
    df["SMA_200"]       = ta.sma(df["Close"], length=200)
    df["EMA_12"]        = ta.ema(df["Close"], length=12)
    df["EMA_26"]        = ta.ema(df["Close"], length=26)
    df["Abstand_SMA20"] = (df["Close"] - df["SMA_20"]) / df["SMA_20"]
    df["Abstand_SMA50"] = (df["Close"] - df["SMA_50"]) / df["SMA_50"]
    df["Abstand_SMA200"]= (df["Close"] - df["SMA_200"]) / df["SMA_200"]
    df["SMA_Kreuz"]     = (df["SMA_20"] > df["SMA_50"]).astype(int)
    # Trendfilter: über SMA200 = Aufwärtstrend
    df["Ueber_SMA200"]  = (df["Close"] > df["SMA_200"]).astype(int)
    # Trendstärke: Abstand SMA20 von SMA50 normiert
    df["Trend_Staerke"] = (df["SMA_20"] - df["SMA_50"]) / df["SMA_50"]

    # ── Momentum ──
    df["RSI"]           = ta.rsi(df["Close"], length=14)
    df["RSI_Trend"]     = df["RSI"] - df["RSI"].shift(3)
    df["RSI_Ueberkauft"]= np.where(df["RSI"] > 70, 1, np.where(df["RSI"] < 30, -1, 0))

    macd = ta.macd(df["Close"])
    macd_col   = [c for c in macd.columns if c.startswith("MACD_") and "s" not in c.lower()][0]
    signal_col = [c for c in macd.columns if c.startswith("MACDs_")][0]
    hist_col   = [c for c in macd.columns if c.startswith("MACDh_")][0]
    df["MACD"]          = macd[macd_col]
    df["MACD_Signal"]   = macd[signal_col]
    df["MACD_Hist"]     = macd[hist_col]   # Histogramm: Dynamik des Trends

    # Stochastik (Überkauft/Überverkauft sensibler als RSI)
    stoch = ta.stoch(df["High"], df["Low"], df["Close"])
    if stoch is not None and len(stoch.columns) >= 2:
        df["Stoch_K"] = stoch.iloc[:, 0]
        df["Stoch_D"] = stoch.iloc[:, 1]
    else:
        df["Stoch_K"] = 50.0
        df["Stoch_D"] = 50.0

    # ── Volatilität ──
    bb = ta.bbands(df["Close"], length=20)
    bb_upper = [c for c in bb.columns if c.startswith("BBU")][0]
    bb_lower = [c for c in bb.columns if c.startswith("BBL")][0]
    df["BB_Width"]      = (bb[bb_upper] - bb[bb_lower]) / df["Close"]
    df["BB_Position"]   = (df["Close"] - bb[bb_lower]) / (bb[bb_upper] - bb[bb_lower] + 1e-9)

    atr = ta.atr(df["High"], df["Low"], df["Close"], length=14)
    df["ATR_norm"]      = atr / df["Close"]

    # Realisierte Volatilität (20-Tage Std der täglichen Renditen)
    df["Volatilitaet_20"]     = df["Close"].pct_change().rolling(20).std()
    # Volatilitäts-Regime: hoch=1 wenn über 75. Perzentil der letzten 252 Tage
    vol_roll_75 = df["Volatilitaet_20"].rolling(252, min_periods=60).quantile(0.75)
    df["Volatilitaet_Regime"] = (df["Volatilitaet_20"] > vol_roll_75).astype(int)

    # ── Volumen ──
    df["Volume_SMA"]    = ta.sma(df["Volume"], length=20)
    df["Volume_Ratio"]  = df["Volume"] / (df["Volume_SMA"] + 1e-9)
    df["Volume_Trend"]  = (df["Volume"] > df["Volume"].shift(1)).astype(int)
    # On-Balance-Volume Trend (steigt OBV → Akkumulation)
    obv = ta.obv(df["Close"], df["Volume"])
    df["OBV_Trend"]     = (obv > obv.shift(5)).astype(int)

    # ── Renditen ──
    df["Return_1d"]     = df["Close"].pct_change(1)
    df["Return_5d"]     = df["Close"].pct_change(5)
    df["Return_20d"]    = df["Close"].pct_change(20)
    df["Return_60d"]    = df["Close"].pct_change(60)
    df["Return_1d_pos"] = (df["Return_1d"] > 0).astype(int)
    # Rendite-Konsistenz: wie oft positiv in den letzten 10 Tagen
    df["Rendite_Konsistenz"] = df["Return_1d_pos"].rolling(10).mean()

    # ── Kurs-Muster ──
    df["Higher_High"]   = (df["High"] > df["High"].shift(1)).astype(int)
    df["Lower_Low"]     = (df["Low"]  < df["Low"].shift(1)).astype(int)
    df["Gap_Up"]        = (df["Open"] > df["Close"].shift(1)).astype(int)
    df["Kerze_Groesse"] = (df["High"] - df["Low"]) / (df["Close"] + 1e-9)
    # Doji: Eröffnung ≈ Schluss (Unentschlossenheit)
    df["Doji"]          = (abs(df["Open"] - df["Close"]) / (df["High"] - df["Low"] + 1e-9) < 0.1).astype(int)

    # ── Saisonalität ──
    df["Wochentag"]     = df.index.dayofweek
    df["Monat"]         = df.index.month
    df["Quartal"]       = df.index.quarter   # Q1-Effekt, Dividendensaison usw.

    # ── Zielvariable ──
    df["Target"] = (df["Close"].shift(-vorausschau) / df["Close"] - 1 > ziel_rendite).astype(int)

    df.dropna(inplace=True)
    if len(df) < 100:
        return None
    return df


def _optuna_optimiere(X_train_s, y_train, n_trials=25):
    """
    Optuna-Hyperparameter-Suche (läuft nur wenn optuna installiert ist).
    Gibt beste XGBoost-Parameter zurück.
    """
    def objective(trial):
        params = {
            "n_estimators":    trial.suggest_int("n_estimators", 200, 800),
            "max_depth":       trial.suggest_int("max_depth", 3, 6),
            "learning_rate":   trial.suggest_float("learning_rate", 0.01, 0.1, log=True),
            "subsample":       trial.suggest_float("subsample", 0.6, 1.0),
            "colsample_bytree":trial.suggest_float("colsample_bytree", 0.6, 1.0),
            "min_child_weight":trial.suggest_int("min_child_weight", 5, 30),
            "gamma":           trial.suggest_float("gamma", 0.0, 0.5),
            "reg_alpha":       trial.suggest_float("reg_alpha", 0.0, 1.0),
            "reg_lambda":      trial.suggest_float("reg_lambda", 0.5, 3.0),
            "eval_metric": "logloss", "random_state": 42,
            "verbosity": 0, "n_jobs": -1,
        }
        # Walk-Forward mit 5 Folds für Optuna
        tscv   = TimeSeriesSplit(n_splits=5)
        scores = []
        for tr_idx, te_idx in tscv.split(X_train_s):
            m = XGBClassifier(**params)
            m.fit(X_train_s[tr_idx], y_train.iloc[tr_idx])
            proba = m.predict_proba(X_train_s[te_idx])[:, 1]
            try:
                scores.append(roc_auc_score(y_train.iloc[te_idx], proba))
            except Exception:
                scores.append(0.5)
        return float(np.mean(scores))

    study = optuna.create_study(direction="maximize",
                                sampler=optuna.samplers.TPESampler(seed=42))
    study.optimize(objective, n_trials=n_trials, show_progress_bar=False)
    return study.best_params


def lade_oder_trainiere(ticker, df, vorausschau=3):
    """
    v4: RobustScaler + Walk-Forward CV (10 Folds) + Optuna (wenn verfügbar)
        + optionales LightGBM-Ensemble
    """
    modell_pfad  = os.path.join(MODELL_ORDNER, f"{ticker.replace('.', '_')}_modell_v4.pkl")
    scaler_pfad  = os.path.join(MODELL_ORDNER, f"{ticker.replace('.', '_')}_scaler_v4.pkl")
    meta_pfad    = os.path.join(MODELL_ORDNER, f"{ticker.replace('.', '_')}_meta_v4.pkl")

    if os.path.exists(modell_pfad) and os.path.exists(scaler_pfad):
        meta = joblib.load(meta_pfad) if os.path.exists(meta_pfad) else {}
        return joblib.load(modell_pfad), joblib.load(scaler_pfad), meta.get("acc")

    X      = df[FEATURES]
    y      = df["Target"]

    # RobustScaler: robuster gegen Ausreißer als StandardScaler
    scaler = RobustScaler()
    X_s    = scaler.fit_transform(X)

    # ── Optuna Hyperparameter-Optimierung ──
    if OPTUNA_VERFUEGBAR:
        print(f"  [{ticker}] Optuna-Suche läuft (25 Trials)...")
        beste_params = _optuna_optimiere(X_s, y, n_trials=25)
        xgb_params   = {**beste_params,
                        "eval_metric": "logloss", "random_state": 42,
                        "verbosity": 0, "n_jobs": -1}
    else:
        # Gute Standardwerte wenn kein Optuna
        xgb_params = {
            "n_estimators": 600, "max_depth": 4, "learning_rate": 0.02,
            "subsample": 0.75, "colsample_bytree": 0.75, "min_child_weight": 15,
            "gamma": 0.1, "reg_alpha": 0.1, "reg_lambda": 1.5,
            "eval_metric": "logloss", "random_state": 42,
            "verbosity": 0, "n_jobs": -1,
        }

    # ── Walk-Forward Kreuzvalidierung (10 Folds) ──
    # Mehr Folds = bessere Schätzung, weniger Overfitting-Risiko
    tscv           = TimeSeriesSplit(n_splits=10)
    alle_preds     = []
    alle_proba     = []
    alle_true      = []
    fold_accs      = []

    for tr_idx, te_idx in tscv.split(X_s):
        X_tr, X_te   = X_s[tr_idx], X_s[te_idx]
        y_tr, y_te   = y.iloc[tr_idx], y.iloc[te_idx]

        # XGBoost
        xgb = XGBClassifier(**xgb_params)
        xgb.fit(X_tr, y_tr)
        xgb_proba = xgb.predict_proba(X_te)[:, 1]

        # LightGBM Ensemble (wenn verfügbar)
        if LGBM_VERFUEGBAR:
            lgbm = lgb.LGBMClassifier(
                n_estimators=500, max_depth=4, learning_rate=0.03,
                subsample=0.75, colsample_bytree=0.75, min_child_samples=20,
                reg_alpha=0.1, reg_lambda=1.0, random_state=42,
                verbose=-1, n_jobs=-1
            )
            lgbm.fit(X_tr, y_tr)
            lgbm_proba = lgbm.predict_proba(X_te)[:, 1]
            # Ensemble: 60% XGBoost + 40% LightGBM
            fold_proba = 0.6 * xgb_proba + 0.4 * lgbm_proba
        else:
            fold_proba = xgb_proba

        fold_preds = (fold_proba >= 0.5).astype(int)
        alle_preds.extend(fold_preds)
        alle_proba.extend(fold_proba)
        alle_true.extend(y_te)
        fold_accs.append(accuracy_score(y_te, fold_preds))

    acc     = float(accuracy_score(alle_true, alle_preds))
    try:
        auc = float(roc_auc_score(alle_true, alle_proba))
    except Exception:
        auc = 0.0

    # Overfitting-Check: Warnung wenn Fold-Varianz zu hoch
    fold_std = float(np.std(fold_accs))

    # ── Final-Training auf allen Daten ──
    xgb_final = XGBClassifier(**xgb_params)
    xgb_final.fit(X_s, y)

    if LGBM_VERFUEGBAR:
        lgbm_final = lgb.LGBMClassifier(
            n_estimators=500, max_depth=4, learning_rate=0.03,
            subsample=0.75, colsample_bytree=0.75, min_child_samples=20,
            reg_alpha=0.1, reg_lambda=1.0, random_state=42,
            verbose=-1, n_jobs=-1
        )
        lgbm_final.fit(X_s, y)
        # Modell als Tuple speichern: (xgb, lgbm, ensemble_weights)
        final_model = (xgb_final, lgbm_final, (0.6, 0.4))
    else:
        final_model = xgb_final

    meta = {
        "acc":       round(acc * 100, 1),
        "auc":       round(auc, 3),
        "fold_std":  round(fold_std, 3),
        "ensemble":  LGBM_VERFUEGBAR,
        "optuna":    OPTUNA_VERFUEGBAR,
        "n_features":len(FEATURES),
        "trainiert": datetime.today().strftime("%d.%m.%Y %H:%M"),
    }

    joblib.dump(final_model, modell_pfad)
    joblib.dump(scaler,      scaler_pfad)
    joblib.dump(meta,        meta_pfad)
    return final_model, scaler, round(acc * 100, 1)


def predict_proba_ensemble(model, X_scaled):
    """Einheitliche predict_proba die sowohl Einzel-Modell als auch Ensemble unterstützt."""
    if isinstance(model, tuple):
        xgb, lgbm, (w_xgb, w_lgbm) = model
        return w_xgb * xgb.predict_proba(X_scaled)[:, 1] +                w_lgbm * lgbm.predict_proba(X_scaled)[:, 1]
    else:
        return model.predict_proba(X_scaled)[:, 1]


def fig_to_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=130, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")

# ============================================================
# 🌐  API ROUTEN
# ============================================================

@app.route("/")
def index():
    return send_from_directory(".", "index.html")


@app.route("/api/signal", methods=["POST"])
def get_signal():
    """Gibt das aktuelle Kaufsignal für eine Aktie zurück."""
    data        = request.json
    ticker      = data.get("ticker", "BAS.DE").upper()
    vorausschau = int(data.get("vorausschau", 3))
    ziel        = float(data.get("ziel_rendite", 0.01))
    konfidenz   = float(data.get("konfidenz", 0.55))

    try:
        df_roh = lade_daten(ticker)
        if df_roh is None:
            return jsonify({"error": f"Keine Daten für {ticker} gefunden."}), 400

        df = berechne_indikatoren(df_roh, vorausschau, ziel)
        if df is None or len(df) < 60:
            return jsonify({"error": f"Zu wenig Daten für {ticker} nach Indikator-Berechnung. Mindestens 60 Handelstage nötig."}), 400

        model, scaler, acc = lade_oder_trainiere(ticker, df, vorausschau)

        letzter       = df[FEATURES].iloc[[-1]]
        wkeit         = float(predict_proba_ensemble(model, scaler.transform(letzter))[0])
        kurs          = float(df["Close"].iloc[-1])
        datum         = df.index[-1].strftime("%d.%m.%Y")
        rsi           = float(df["RSI"].iloc[-1])
        macd          = float(df["MACD"].iloc[-1])
        vol           = float(df["Volume_Ratio"].iloc[-1])
        sma_kreuz     = int(df["SMA_Kreuz"].iloc[-1])
        bb_pos        = float(df["BB_Position"].iloc[-1])
        ret_5d        = float(df["Return_5d"].iloc[-1] * 100)
        ret_20d       = float(df["Return_20d"].iloc[-1] * 100)

        if wkeit >= 0.65:
            signal_text  = "STARK KAUFEN"
            signal_klasse = "stark"
        elif wkeit >= konfidenz:
            signal_text  = "SCHWACH KAUFEN"
            signal_klasse = "schwach"
        else:
            signal_text  = "NICHT KAUFEN"
            signal_klasse = "nein"

        # Kurschart der letzten 90 Tage
        fig, ax = plt.subplots(figsize=(9, 3))
        fig.patch.set_facecolor("#0f1117")
        ax.set_facecolor("#0f1117")
        letzten_90 = df_roh.tail(90)
        ax.plot(letzten_90.index, letzten_90["Close"],
                color="#4fa3e0", linewidth=1.5)
        ax.fill_between(letzten_90.index, letzten_90["Close"],
                        letzten_90["Close"].min(),
                        alpha=0.1, color="#4fa3e0")
        ax.set_title(f"{ticker} – letzte 90 Tage", color="white", fontsize=11)
        ax.tick_params(colors="gray", labelsize=8)
        for spine in ax.spines.values():
            spine.set_edgecolor("#2a2a3a")
        ax.grid(True, alpha=0.15, color="gray")
        plt.tight_layout()
        kurs_chart = fig_to_base64(fig)
        plt.close()

        return jsonify({
            "ticker":       str(ticker),
            "datum":        str(datum),
            "kurs":         round(float(kurs), 2),
            "signal":       str(signal_text),
            "signal_klasse":str(signal_klasse),
            "wahrsch":      round(float(wkeit) * 100, 1),
            "rsi":          round(float(rsi), 1),
            "macd":         round(float(macd), 4),
            "volume_ratio": round(float(vol), 2),
            "sma_kreuz":    int(sma_kreuz),
            "bb_position":  round(float(bb_pos), 2),
            "rendite_5d":   round(float(ret_5d), 2),
            "rendite_20d":  round(float(ret_20d), 2),
            "accuracy":     float(acc) if acc else None,
            "ensemble":     bool(LGBM_VERFUEGBAR),
            "optuna":       bool(OPTUNA_VERFUEGBAR),
            "kurs_chart":   kurs_chart,
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/backtest", methods=["POST"])
def run_backtest():
    """Führt einen Backtest durch und gibt Ergebnisse + Charts zurück."""
    data            = request.json
    ticker          = data.get("ticker", "BAS.DE").upper()
    startkapital    = float(data.get("startkapital", 1000))
    konfidenz       = float(data.get("konfidenz", 0.55))
    vorausschau     = int(data.get("vorausschau", 3))
    ziel            = float(data.get("ziel_rendite", 0.01))
    kosten          = float(data.get("transaktionskosten", 0.001))
    positions_modus  = data.get("positions_modus", "voll")   # voll | fix | kelly
    positions_pct    = float(data.get("positions_pct", 100)) / 100
    # Stop-Loss Einstellungen
    sl_modus         = data.get("sl_modus", "kein")          # kein | fix | trailing
    sl_pct           = float(data.get("sl_pct", 2.0)) / 100  # z.B. 2% → 0.02
    tp_aktiv         = bool(data.get("tp_aktiv", False))
    tp_pct           = float(data.get("tp_pct", 4.0)) / 100  # z.B. 4% → 0.04

    try:
        df_roh = lade_daten(ticker)
        if df_roh is None:
            return jsonify({"error": f"Keine Daten für {ticker}"}), 400

        df = berechne_indikatoren(df_roh, vorausschau, ziel)
        if df is None or len(df) < 100:
            return jsonify({"error": f"Zu wenig Daten für {ticker}. Mindestens 100 Handelstage nach Indikator-Berechnung nötig."}), 400

        # Walk-Forward Split
        split_idx   = int(len(df) * 0.60)
        df_train    = df.iloc[:split_idx]
        df_backtest = df.iloc[split_idx:].copy()

        if len(df_train) < 50:
            return jsonify({"error": "Trainingsdatensatz zu klein (< 50 Tage). Bitte früheres Startdatum wählen."}), 400
        if len(df_backtest) < 10:
            return jsonify({"error": "Backtest-Zeitraum zu klein (< 10 Tage). Mehr historische Daten nötig."}), 400

        scaler  = RobustScaler()
        X_train = scaler.fit_transform(df_train[FEATURES])
        model   = XGBClassifier(
            n_estimators=600, max_depth=4, learning_rate=0.02,
            subsample=0.75, colsample_bytree=0.75, min_child_weight=15,
            gamma=0.1, reg_alpha=0.1, reg_lambda=1.5,
            eval_metric="logloss", random_state=42, verbosity=0, n_jobs=-1
        )
        if LGBM_VERFUEGBAR:
            lgbm_bt = lgb.LGBMClassifier(
                n_estimators=500, max_depth=4, learning_rate=0.03,
                subsample=0.75, colsample_bytree=0.75, min_child_samples=20,
                reg_alpha=0.1, reg_lambda=1.0, random_state=42, verbose=-1, n_jobs=-1
            )
            lgbm_bt.fit(X_train, df_train["Target"])
            model.fit(X_train, df_train["Target"])
            model = (model, lgbm_bt, (0.6, 0.4))
        else:
            model.fit(X_train, df_train["Target"])

        X_backtest  = scaler.transform(df_backtest[FEATURES])
        wahrsch     = predict_proba_ensemble(model, X_backtest)
        vorhersagen = (wahrsch >= konfidenz).astype(int)

        # ── Positionsgröße berechnen ──
        # Erst nach der Simulation bekannt (Kelly braucht Trefferquote),
        # daher: erster Pass für Kelly-Kalibrierung auf Trainingsdaten
        kelly_pct = 1.0  # Fallback
        if positions_modus == "kelly":
            try:
                tr_proba = predict_proba_ensemble(model, X_train)
                tr_preds = (tr_proba >= 0.5).astype(int)
                tr_true  = df_train["Target"].values
                if len(tr_preds) == 0 or len(tr_true) == 0:
                    raise ValueError("Leere Trainingsdaten")
                tr_r   = df_train["Close"].pct_change(vorausschau).shift(-vorausschau).dropna()
                gew_tr = tr_r[tr_r > 0].mean() * 100 if (tr_r > 0).any() else 2.0
                ver_tr = abs(tr_r[tr_r <= 0].mean()) * 100 if (tr_r <= 0).any() else 2.0
                tq_tr  = float((tr_preds == tr_true).mean())
                if ver_tr > 0 and gew_tr > 0 and not np.isnan(gew_tr) and not np.isnan(ver_tr):
                    kelly_pct = max(0.05, min(0.50,
                        tq_tr - (1 - tq_tr) / (gew_tr / ver_tr)
                    ))
                else:
                    kelly_pct = 0.25
            except Exception:
                kelly_pct = 0.25  # sicherer Fallback

        def berechne_positionsgroesse(kapital, modus, pct, kelly):
            if modus == "voll":
                return kapital          # 100% investieren
            elif modus == "fix":
                return kapital * pct    # z.B. 20% investieren
            elif modus == "kelly":
                return kapital * kelly  # Kelly-Anteil investieren
            return kapital

        # ── Simulation mit Stop-Loss & Take-Profit ──
        kapital           = startkapital
        kapital_kurve     = [startkapital]
        trades            = []
        in_position       = False
        kauf_kurs         = 0.0
        kauf_datum        = None
        investiert        = 0.0
        trailing_high     = 0.0   # höchster Kurs seit Kauf (für Trailing Stop)
        sl_exits          = 0     # Zähler: wie oft Stop-Loss ausgelöst
        tp_exits          = 0     # Zähler: wie oft Take-Profit ausgelöst
        normal_exits      = 0     # Zähler: normale Vorausschau-Exits

        close_arr = df_backtest["Close"].values.astype(float)
        high_arr  = df_backtest["High"].values.astype(float)
        low_arr   = df_backtest["Low"].values.astype(float)
        n_bt      = len(df_backtest)

        for i in range(n_bt - vorausschau):
            kurs      = close_arr[i]
            signal    = vorhersagen[i]
            wkeit_i   = float(wahrsch[i])
            echt_ziel = int(df_backtest["Target"].iloc[i])

            if signal == 1 and not in_position:
                # ── KAUFEN ──
                investiert    = berechne_positionsgroesse(
                    kapital, positions_modus, positions_pct, kelly_pct)
                investiert   -= investiert * kosten
                kauf_kurs     = kurs
                kauf_datum    = df_backtest.index[i]
                trailing_high = kurs
                in_position   = True

            elif in_position:
                # ── Stop-Loss & Take-Profit täglich prüfen ──
                exit_kurs   = None
                exit_grund  = "vorausschau"

                # Tages-High/Low für intraday SL/TP Simulation
                tages_high = high_arr[i]
                tages_low  = low_arr[i]

                # Trailing Stop: höchsten Kurs aktualisieren
                if sl_modus == "trailing":
                    trailing_high = max(trailing_high, tages_high)
                    trailing_sl   = trailing_high * (1 - sl_pct)
                    if tages_low <= trailing_sl:
                        exit_kurs  = trailing_sl
                        exit_grund = "trailing_sl"

                # Fix Stop-Loss
                elif sl_modus == "fix":
                    fix_sl = kauf_kurs * (1 - sl_pct)
                    if tages_low <= fix_sl:
                        exit_kurs  = fix_sl
                        exit_grund = "fix_sl"

                # Take-Profit
                if tp_aktiv and exit_kurs is None:
                    tp_level = kauf_kurs * (1 + tp_pct)
                    if tages_high >= tp_level:
                        exit_kurs  = tp_level
                        exit_grund = "take_profit"

                # Normaler Exit nach Vorausschau-Tagen
                if exit_kurs is None:
                    exit_idx   = min(i + vorausschau - 1, n_bt - 1)
                    exit_kurs  = close_arr[exit_idx]
                    exit_datum = df_backtest.index[exit_idx]
                else:
                    exit_datum = df_backtest.index[i]

                rendite    = (exit_kurs - kauf_kurs) / kauf_kurs
                gewinn     = investiert * rendite - investiert * kosten
                kapital   += gewinn
                in_position = False

                # Exit-Zähler
                if exit_grund == "trailing_sl" or exit_grund == "fix_sl":
                    sl_exits += 1
                elif exit_grund == "take_profit":
                    tp_exits += 1
                else:
                    normal_exits += 1

                trades.append({
                    "kauf_datum":    kauf_datum.strftime("%d.%m.%Y"),
                    "verkauf_datum": exit_datum.strftime("%d.%m.%Y"),
                    "kauf_kurs":     round(kauf_kurs, 2),
                    "verkauf_kurs":  round(exit_kurs, 2),
                    "rendite":       round(rendite * 100, 2),
                    "investiert":    round(investiert, 2),
                    "wahrsch":       round(wkeit_i * 100, 1),
                    "exit_grund":    exit_grund,
                    "richtig":       "JA" if (rendite > 0) == (echt_ziel == 1) else "NEIN",
                })

            kapital_kurve.append(max(kapital, 0.01))

        # Offene Position am Ende schließen
        if in_position:
            exit_kurs  = close_arr[-1]
            rendite    = (exit_kurs - kauf_kurs) / kauf_kurs
            gewinn     = investiert * rendite
            kapital   += gewinn
            kapital_kurve.append(max(kapital, 0.01))

        trades_df     = pd.DataFrame(trades)
        endkapital    = kapital_kurve[-1]
        gesamtrendite = (endkapital - startkapital) / startkapital * 100
        if len(df_backtest) < 2 or float(df_backtest["Close"].iloc[0]) == 0:
            bah_rendite = 0.0
        else:
            bah_rendite = (float(df_backtest["Close"].iloc[-1]) /
                           float(df_backtest["Close"].iloc[0]) - 1) * 100

        if len(trades_df) > 0:
            richtige      = (trades_df["richtig"] == "JA").sum()
            trefferquote  = richtige / len(trades_df) * 100
            gew           = trades_df[trades_df["rendite"] > 0]["rendite"]
            ver           = trades_df[trades_df["rendite"] <= 0]["rendite"]
            avg_gewinn    = gew.mean() if len(gew) > 0 else 0
            avg_verlust   = ver.mean() if len(ver) > 0 else 0
            pf            = gew.sum() / abs(ver.sum()) if abs(ver.sum()) > 0 else 0
        else:
            trefferquote = richtige = avg_gewinn = avg_verlust = pf = 0

        if len(kapital_kurve) < 2:
            kapital_kurve = [startkapital, startkapital]
        kurve_arr    = np.array(kapital_kurve)
        peak         = np.maximum.accumulate(kurve_arr)
        with np.errstate(divide="ignore", invalid="ignore"):
            drawdown_arr = np.where(peak > 0, (kurve_arr - peak) / peak * 100, 0.0)
        max_drawdown = float(drawdown_arr.min()) if len(drawdown_arr) > 0 else 0.0

        # ── Charts ──
        fig = plt.figure(figsize=(11, 8))
        fig.patch.set_facecolor("#0f1117")
        gs  = gridspec.GridSpec(3, 1, figure=fig, hspace=0.5)

        # Chart 1: Kursverlauf
        ax1 = fig.add_subplot(gs[0])
        ax1.set_facecolor("#0f1117")
        ax1.plot(df_backtest.index, df_backtest["Close"],
                 color="#4fa3e0", linewidth=1)
        ax1.set_title(f"{ticker} – Kursverlauf (Backtest-Zeitraum)",
                      color="white", fontsize=10)
        ax1.tick_params(colors="gray", labelsize=7)
        ax1.grid(True, alpha=0.12, color="gray")
        for spine in ax1.spines.values():
            spine.set_edgecolor("#2a2a3a")
        if len(trades) > 0:
            for t in trades:
                try:
                    kdt = pd.to_datetime(t["kauf_datum"], format="%d.%m.%Y")
                    vdt = pd.to_datetime(t["verkauf_datum"], format="%d.%m.%Y")
                    ax1.axvline(kdt, color="#4fa3e0", alpha=0.3, linewidth=0.7)
                    farbe = "#4caf50" if t["rendite"] > 0 else "#f44336"
                    ax1.axvline(vdt, color=farbe, alpha=0.3, linewidth=0.7)
                except:
                    pass

        # Chart 2: Equity-Kurve
        ax2 = fig.add_subplot(gs[1])
        ax2.set_facecolor("#0f1117")
        n   = min(len(kapital_kurve), len(df_backtest))
        kx  = df_backtest.index[:n]
        ky  = kapital_kurve[:n]
        bah_start = float(df_backtest["Close"].iloc[0]) if len(df_backtest) > 0 and float(df_backtest["Close"].iloc[0]) != 0 else 1.0
        bah_k = startkapital * (df_backtest["Close"].iloc[:n] / bah_start)
        ax2.plot(kx, ky, color="#4fa3e0", linewidth=1.5, label="Modell")
        ax2.plot(kx, bah_k, color="#ff9800", linewidth=1.5,
                 linestyle="--", label="Buy & Hold")
        ax2.axhline(startkapital, color="#555", linestyle=":", linewidth=0.8)
        ax2.fill_between(kx, ky, startkapital,
                         where=[v >= startkapital for v in ky],
                         alpha=0.15, color="#4caf50")
        ax2.fill_between(kx, ky, startkapital,
                         where=[v < startkapital for v in ky],
                         alpha=0.15, color="#f44336")
        ax2.set_title("Equity-Kurve vs. Buy & Hold", color="white", fontsize=10)
        ax2.tick_params(colors="gray", labelsize=7)
        ax2.grid(True, alpha=0.12, color="gray")
        ax2.legend(fontsize=8, facecolor="#1a1a2e", labelcolor="white")
        for spine in ax2.spines.values():
            spine.set_edgecolor("#2a2a3a")

        # Chart 3: Drawdown
        ax3 = fig.add_subplot(gs[2])
        ax3.set_facecolor("#0f1117")
        ax3.fill_between(kx, drawdown_arr[:n], 0, color="#f44336", alpha=0.5)
        ax3.plot(kx, drawdown_arr[:n], color="#f44336", linewidth=0.8)
        ax3.set_title("Drawdown (%)", color="white", fontsize=10)
        ax3.tick_params(colors="gray", labelsize=7)
        ax3.grid(True, alpha=0.12, color="gray")
        for spine in ax3.spines.values():
            spine.set_edgecolor("#2a2a3a")

        plt.tight_layout()
        backtest_chart = fig_to_base64(fig)
        plt.close()

        return jsonify({
            "ticker":           str(ticker),
            "startkapital":     float(startkapital),
            "endkapital":       round(float(endkapital), 2),
            "gesamtrendite":    round(float(gesamtrendite), 2),
            "bah_rendite":      round(float(bah_rendite), 2),
            "vorteil":          round(float(gesamtrendite - bah_rendite), 2),
            "anzahl_trades":    int(len(trades)),
            "trefferquote":     round(float(trefferquote), 1),
            "avg_gewinn":       round(float(avg_gewinn), 2),
            "avg_verlust":      round(float(avg_verlust), 2),
            "profit_factor":    round(float(pf), 2),
            "max_drawdown":     round(float(max_drawdown), 2),
            "backtest_chart":   backtest_chart,
            "trades":           [
                {k: (float(v) if isinstance(v, (np.floating, float)) else
                     int(v)   if isinstance(v, (np.integer,)) else
                     str(v))
                 for k, v in t.items()}
                for t in trades[-20:]
            ],
            "training_von":     df_train.index[0].strftime("%d.%m.%Y"),
            "training_bis":     df_train.index[-1].strftime("%d.%m.%Y"),
            "backtest_von":     df_backtest.index[0].strftime("%d.%m.%Y"),
            "backtest_bis":     df_backtest.index[-1].strftime("%d.%m.%Y"),
            "positions_modus":  str(positions_modus),
            "kelly_pct":        round(float(kelly_pct) * 100, 1) if positions_modus == "kelly" else None,
            "positions_pct":    round(float(positions_pct) * 100, 1) if positions_modus == "fix" else None,
            "sl_modus":         str(sl_modus),
            "sl_pct":           round(sl_pct * 100, 1),
            "tp_aktiv":         bool(tp_aktiv),
            "tp_pct":           round(tp_pct * 100, 1),
            "sl_exits":         int(sl_exits),
            "tp_exits":         int(tp_exits),
            "normal_exits":     int(normal_exits),
        })

    except Exception as e:
        import traceback
        return jsonify({"error": str(e), "detail": traceback.format_exc()}), 500



# ============================================================
# 🌍  MULTI-AKTIEN TEST ENDPOINT
# ============================================================

def run_single_backtest(ticker, params):
    """
    Führt einen vollständigen Backtest für eine einzelne Aktie durch.
    Gibt ein Dict mit allen Kennzahlen zurück (oder Fehler-Dict).
    """
    try:
        vorausschau    = int(params.get("vorausschau", 3))
        ziel           = float(params.get("ziel_rendite", 0.01))
        konfidenz      = float(params.get("konfidenz", 0.55))
        startkapital   = float(params.get("startkapital", 1000))
        kosten         = float(params.get("transaktionskosten", 0.001))
        positions_modus= params.get("positions_modus", "voll")
        positions_pct  = float(params.get("positions_pct", 100)) / 100
        sl_modus       = params.get("sl_modus", "kein")
        sl_pct         = float(params.get("sl_pct", 2.0)) / 100
        tp_aktiv       = bool(params.get("tp_aktiv", False))
        tp_pct         = float(params.get("tp_pct", 4.0)) / 100

        df_roh = lade_daten(ticker)
        if df_roh is None:
            return {"ticker": ticker, "fehler": "Keine Daten gefunden"}

        df = berechne_indikatoren(df_roh, vorausschau, ziel)
        if df is None or len(df) < 100:
            return {"ticker": ticker, "fehler": "Zu wenig Daten"}

        split_idx   = int(len(df) * 0.60)
        df_train    = df.iloc[:split_idx]
        df_backtest = df.iloc[split_idx:].copy()

        if len(df_train) < 50 or len(df_backtest) < 10:
            return {"ticker": ticker, "fehler": "Split zu klein"}

        scaler  = RobustScaler()
        X_train = scaler.fit_transform(df_train[FEATURES])
        model   = XGBClassifier(
            n_estimators=600, max_depth=4, learning_rate=0.02,
            subsample=0.75, colsample_bytree=0.75, min_child_weight=15,
            gamma=0.1, reg_alpha=0.1, reg_lambda=1.5,
            eval_metric="logloss", random_state=42, verbosity=0, n_jobs=-1
        )
        if LGBM_VERFUEGBAR:
            lgbm_bt = lgb.LGBMClassifier(
                n_estimators=500, max_depth=4, learning_rate=0.03,
                subsample=0.75, colsample_bytree=0.75, min_child_samples=20,
                reg_alpha=0.1, reg_lambda=1.0, random_state=42, verbose=-1, n_jobs=-1
            )
            lgbm_bt.fit(X_train, df_train["Target"])
            model.fit(X_train, df_train["Target"])
            model = (model, lgbm_bt, (0.6, 0.4))
        else:
            model.fit(X_train, df_train["Target"])

        X_bt        = scaler.transform(df_backtest[FEATURES])
        wahrsch     = predict_proba_ensemble(model, X_bt)
        vorhersagen = (wahrsch >= konfidenz).astype(int)

        # Kelly
        kelly_pct = 0.25
        if positions_modus == "kelly":
            try:
                tr_proba = predict_proba_ensemble(model, X_train)
                tr_preds = (tr_proba >= 0.5).astype(int)
                tr_r   = df_train["Close"].pct_change(vorausschau).shift(-vorausschau).dropna()
                gew_tr = tr_r[tr_r > 0].mean() * 100 if (tr_r > 0).any() else 2.0
                ver_tr = abs(tr_r[tr_r <= 0].mean()) * 100 if (tr_r <= 0).any() else 2.0
                tq_tr  = float((tr_preds == df_train["Target"].values).mean())
                if ver_tr > 0 and gew_tr > 0:
                    kelly_pct = max(0.05, min(0.50, tq_tr - (1 - tq_tr) / (gew_tr / ver_tr)))
            except Exception:
                kelly_pct = 0.25

        def pos_size(kap, modus, pct, kelly):
            if modus == "fix":    return kap * pct
            if modus == "kelly":  return kap * kelly
            return kap

        kapital       = startkapital
        kapital_kurve = [startkapital]
        trades        = []
        in_position   = False
        kauf_kurs     = 0.0
        kauf_datum    = None
        investiert    = 0.0
        trailing_high = 0.0
        sl_exits = tp_exits = normal_exits = 0

        close_arr = df_backtest["Close"].values.astype(float)
        high_arr  = df_backtest["High"].values.astype(float)
        low_arr   = df_backtest["Low"].values.astype(float)
        n_bt      = len(df_backtest)

        for i in range(n_bt - vorausschau):
            kurs      = close_arr[i]
            signal    = vorhersagen[i]
            wkeit_i   = float(wahrsch[i])
            echt_ziel = int(df_backtest["Target"].iloc[i])

            if signal == 1 and not in_position:
                investiert    = pos_size(kapital, positions_modus, positions_pct, kelly_pct)
                investiert   -= investiert * kosten
                kauf_kurs     = kurs
                kauf_datum    = df_backtest.index[i]
                trailing_high = kurs
                in_position   = True
            elif in_position:
                exit_kurs  = None
                exit_grund = "vorausschau"
                tages_high = high_arr[i]
                tages_low  = low_arr[i]

                if sl_modus == "trailing":
                    trailing_high = max(trailing_high, tages_high)
                    if tages_low <= trailing_high * (1 - sl_pct):
                        exit_kurs  = trailing_high * (1 - sl_pct)
                        exit_grund = "sl"
                elif sl_modus == "fix":
                    if tages_low <= kauf_kurs * (1 - sl_pct):
                        exit_kurs  = kauf_kurs * (1 - sl_pct)
                        exit_grund = "sl"

                if tp_aktiv and exit_kurs is None:
                    if tages_high >= kauf_kurs * (1 + tp_pct):
                        exit_kurs  = kauf_kurs * (1 + tp_pct)
                        exit_grund = "tp"

                if exit_kurs is None:
                    exit_idx   = min(i + vorausschau - 1, n_bt - 1)
                    exit_kurs  = close_arr[exit_idx]
                    exit_datum = df_backtest.index[exit_idx]
                else:
                    exit_datum = df_backtest.index[i]

                rendite    = (exit_kurs - kauf_kurs) / kauf_kurs
                gewinn     = investiert * rendite - investiert * kosten
                kapital   += gewinn
                in_position = False

                if exit_grund == "sl":     sl_exits += 1
                elif exit_grund == "tp":   tp_exits += 1
                else:                      normal_exits += 1

                trades.append({
                    "rendite": rendite,
                    "richtig": "JA" if (rendite > 0) == (echt_ziel == 1) else "NEIN",
                })

            kapital_kurve.append(max(kapital, 0.01))

        if in_position:
            rendite  = (close_arr[-1] - kauf_kurs) / kauf_kurs
            kapital += investiert * rendite
            kapital_kurve.append(max(kapital, 0.01))

        # Kennzahlen
        trades_df     = pd.DataFrame(trades) if trades else pd.DataFrame(columns=["rendite","richtig"])
        endkapital    = float(kapital_kurve[-1])
        gesamtrendite = (endkapital - startkapital) / startkapital * 100
        bah_start     = float(df_backtest["Close"].iloc[0])
        bah_rendite   = (float(df_backtest["Close"].iloc[-1]) / bah_start - 1) * 100 if bah_start != 0 else 0

        if len(trades_df) > 0:
            richtige     = (trades_df["richtig"] == "JA").sum()
            trefferquote = float(richtige) / len(trades_df) * 100
            gew          = trades_df[trades_df["rendite"] > 0]["rendite"]
            ver          = trades_df[trades_df["rendite"] <= 0]["rendite"]
            avg_gewinn   = float(gew.mean() * 100) if len(gew) > 0 else 0
            avg_verlust  = float(ver.mean() * 100) if len(ver) > 0 else 0
            pf           = float(gew.sum() / abs(ver.sum())) if abs(ver.sum()) > 0 else 0
        else:
            trefferquote = avg_gewinn = avg_verlust = pf = 0

        kurve_arr    = np.array(kapital_kurve)
        peak         = np.maximum.accumulate(kurve_arr)
        with np.errstate(divide="ignore", invalid="ignore"):
            dd_arr = np.where(peak > 0, (kurve_arr - peak) / peak * 100, 0.0)
        max_drawdown = float(dd_arr.min()) if len(dd_arr) > 0 else 0.0

        return {
            "ticker":        ticker,
            "fehler":        None,
            "endkapital":    round(endkapital, 2),
            "rendite":       round(gesamtrendite, 2),
            "bah_rendite":   round(bah_rendite, 2),
            "vorteil":       round(gesamtrendite - bah_rendite, 2),
            "trefferquote":  round(trefferquote, 1),
            "profit_factor": round(pf, 2),
            "max_drawdown":  round(max_drawdown, 2),
            "anzahl_trades": int(len(trades_df)),
            "sl_exits":      int(sl_exits),
            "tp_exits":      int(tp_exits),
            "avg_gewinn":    round(avg_gewinn, 2),
            "avg_verlust":   round(avg_verlust, 2),
            "backtest_von":  df_backtest.index[0].strftime("%d.%m.%Y"),
            "backtest_bis":  df_backtest.index[-1].strftime("%d.%m.%Y"),
        }

    except Exception as e:
        return {"ticker": ticker, "fehler": str(e)}


def erstelle_excel(ergebnisse, params):
    """Erstellt eine professionelle Excel-Datei mit den Backtesting-Ergebnissen."""
    wb = Workbook()

    # ── Farben ──
    C_HEADER_BG  = "1A1A2E"
    C_HEADER_FG  = "FFFFFF"
    C_GOOD_BG    = "C6EFCE"
    C_GOOD_FG    = "276221"
    C_BAD_BG     = "FFC7CE"
    C_BAD_FG     = "9C0006"
    C_MID_BG     = "FFEB9C"
    C_MID_FG     = "9C5700"
    C_ALT_BG     = "F5F5F5"
    C_TITLE_BG   = "2E4057"

    thin = Side(style="thin", color="CCCCCC")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    def hdr_cell(ws, row, col, val, width=None):
        c = ws.cell(row=row, column=col, value=val)
        c.font      = Font(bold=True, color=C_HEADER_FG, name="Arial", size=10)
        c.fill      = PatternFill("solid", fgColor=C_HEADER_BG)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border    = border
        if width:
            ws.column_dimensions[get_column_letter(col)].width = width
        return c

    def data_cell(ws, row, col, val, pct=False, bold=False, align="center"):
        c = ws.cell(row=row, column=col, value=val)
        c.font      = Font(name="Arial", size=10, bold=bold)
        c.alignment = Alignment(horizontal=align, vertical="center")
        c.border    = border
        if pct and isinstance(val, (int, float)):
            c.number_format = '+0.00%;-0.00%;"-"'
        if row % 2 == 0:
            c.fill = PatternFill("solid", fgColor=C_ALT_BG)
        return c

    def color_cell(ws, row, col, val, reverse=False):
        """Grün = gut, Rot = schlecht (oder umgekehrt bei reverse=True)"""
        c = ws.cell(row=row, column=col)
        if isinstance(val, (int, float)):
            good  = val > 0 if not reverse else val < 0
            bad   = val < 0 if not reverse else val > 0
            if good:
                c.fill = PatternFill("solid", fgColor=C_GOOD_BG)
                c.font = Font(name="Arial", size=10, color=C_GOOD_FG, bold=True)
            elif bad:
                c.fill = PatternFill("solid", fgColor=C_BAD_BG)
                c.font = Font(name="Arial", size=10, color=C_BAD_FG, bold=True)

    # ══════════════════════════════════════
    #  Sheet 1: Übersicht
    # ══════════════════════════════════════
    ws1 = wb.active
    ws1.title = "Übersicht"
    ws1.freeze_panes = "A4"

    # Titel
    ws1.merge_cells("A1:O1")
    title = ws1["A1"]
    title.value = f"KI-Trading-System – Multi-Aktien Backtest  |  Erstellt: {datetime.today().strftime('%d.%m.%Y %H:%M')}"
    title.font  = Font(bold=True, color="FFFFFF", name="Arial", size=13)
    title.fill  = PatternFill("solid", fgColor=C_TITLE_BG)
    title.alignment = Alignment(horizontal="center", vertical="center")
    ws1.row_dimensions[1].height = 28

    # Parameter-Zeile
    ws1.merge_cells("A2:O2")
    pinfo = ws1["A2"]
    sl_info = f"SL: {params.get('sl_modus','kein').upper()} {params.get('sl_pct',2.0)}%" if params.get('sl_modus','kein') != 'kein' else "SL: Kein"
    tp_info = f"  |  TP: +{params.get('tp_pct',4.0)}%" if params.get('tp_aktiv') else ""
    pinfo.value = (f"Konfidenz ≥ {float(params.get('konfidenz',0.55))*100:.0f}%  |  "
                   f"Vorausschau: {params.get('vorausschau',3)} Tage  |  "
                   f"Startkapital: {params.get('startkapital',1000):.0f}€  |  "
                   f"Pos.-Modus: {params.get('positions_modus','voll').upper()}  |  "
                   f"{sl_info}{tp_info}")
    pinfo.font      = Font(italic=True, name="Arial", size=9, color="666666")
    pinfo.alignment = Alignment(horizontal="center")
    ws1.row_dimensions[2].height = 18

    # Header Row 3
    headers = [
        ("TICKER",        12), ("BACKTEST VON", 13), ("BACKTEST BIS", 13),
        ("RENDITE %",     11), ("B&H RENDITE %", 13), ("VORTEIL %",   11),
        ("TREFFERQUOTE",  13), ("PROFIT FACTOR", 13), ("MAX DRAWDOWN",13),
        ("TRADES",         9), ("SL-EXITS",       9), ("TP-EXITS",     9),
        ("Ø GEWINN %",    11), ("Ø VERLUST %",   11), ("STATUS",      12),
    ]
    ws1.row_dimensions[3].height = 32
    for col, (h, w) in enumerate(headers, 1):
        hdr_cell(ws1, 3, col, h, w)

    # Daten
    ok_count = fehler_count = 0
    for row_i, r in enumerate(ergebnisse, 4):
        ws1.row_dimensions[row_i].height = 20
        is_alt = (row_i % 2 == 0)

        if r.get("fehler"):
            fehler_count += 1
            data_cell(ws1, row_i, 1,  r["ticker"], bold=True, align="left")
            ws1.merge_cells(f"B{row_i}:O{row_i}")
            ec = ws1.cell(row=row_i, column=2, value=f"⚠ FEHLER: {r['fehler']}")
            ec.font      = Font(name="Arial", size=10, color=C_BAD_FG, italic=True)
            ec.fill      = PatternFill("solid", fgColor=C_BAD_BG)
            ec.alignment = Alignment(horizontal="left", vertical="center")
            continue

        ok_count += 1
        rendite  = r["rendite"]
        vorteil  = r["vorteil"]
        drawdown = r["max_drawdown"]
        tq       = r["trefferquote"]
        pf       = r["profit_factor"]

        data_cell(ws1, row_i, 1,  r["ticker"],       bold=True, align="left")
        data_cell(ws1, row_i, 2,  r["backtest_von"])
        data_cell(ws1, row_i, 3,  r["backtest_bis"])
        data_cell(ws1, row_i, 4,  r["rendite"])
        data_cell(ws1, row_i, 5,  r["bah_rendite"])
        data_cell(ws1, row_i, 6,  r["vorteil"])
        data_cell(ws1, row_i, 7,  r["trefferquote"])
        data_cell(ws1, row_i, 8,  r["profit_factor"])
        data_cell(ws1, row_i, 9,  r["max_drawdown"])
        data_cell(ws1, row_i, 10, r["anzahl_trades"])
        data_cell(ws1, row_i, 11, r["sl_exits"])
        data_cell(ws1, row_i, 12, r["tp_exits"])
        data_cell(ws1, row_i, 13, r["avg_gewinn"])
        data_cell(ws1, row_i, 14, r["avg_verlust"])

        # Status
        if rendite > 5 and pf > 1.2:
            status, bg, fg = "⭐ SEHR GUT",  C_GOOD_BG, C_GOOD_FG
        elif rendite > 0 and pf >= 1.0:
            status, bg, fg = "✓ GUT",        C_GOOD_BG, C_GOOD_FG
        elif rendite > -10:
            status, bg, fg = "~ NEUTRAL",    C_MID_BG,  C_MID_FG
        else:
            status, bg, fg = "✗ SCHLECHT",   C_BAD_BG,  C_BAD_FG

        sc = ws1.cell(row=row_i, column=15, value=status)
        sc.font      = Font(name="Arial", size=10, bold=True, color=fg)
        sc.fill      = PatternFill("solid", fgColor=bg)
        sc.alignment = Alignment(horizontal="center", vertical="center")
        sc.border    = border

        # Farbcodierung
        color_cell(ws1, row_i, 4,  rendite)
        color_cell(ws1, row_i, 5,  r["bah_rendite"])
        color_cell(ws1, row_i, 6,  vorteil)
        color_cell(ws1, row_i, 9,  drawdown, reverse=True)
        color_cell(ws1, row_i, 13, r["avg_gewinn"])
        color_cell(ws1, row_i, 14, r["avg_verlust"], reverse=True)

    # Zusammenfassung Zeile
    sum_row = len(ergebnisse) + 4
    ws1.row_dimensions[sum_row].height = 22
    ok_results = [r for r in ergebnisse if not r.get("fehler")]

    sc = ws1.cell(row=sum_row, column=1, value=f"ZUSAMMENFASSUNG ({ok_count} OK, {fehler_count} Fehler)")
    sc.font = Font(bold=True, name="Arial", size=10, color="FFFFFF")
    sc.fill = PatternFill("solid", fgColor=C_TITLE_BG)
    sc.alignment = Alignment(horizontal="left", vertical="center")
    sc.border = border

    if ok_results:
        avg_rendite = sum(r["rendite"] for r in ok_results) / len(ok_results)
        avg_bah     = sum(r["bah_rendite"] for r in ok_results) / len(ok_results)
        avg_tq      = sum(r["trefferquote"] for r in ok_results) / len(ok_results)
        avg_pf      = sum(r["profit_factor"] for r in ok_results) / len(ok_results)
        best        = max(ok_results, key=lambda x: x["rendite"])
        worst       = min(ok_results, key=lambda x: x["rendite"])

        for col, val in [(4, round(avg_rendite,2)), (5, round(avg_bah,2)),
                         (7, round(avg_tq,1)), (8, round(avg_pf,2))]:
            c = ws1.cell(row=sum_row, column=col, value=val)
            c.font = Font(bold=True, name="Arial", size=10, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor=C_TITLE_BG)
            c.alignment = Alignment(horizontal="center")
            c.border = border

    # ══════════════════════════════════════
    #  Sheet 2: Ranking (sortiert nach Rendite)
    # ══════════════════════════════════════
    ws2 = wb.create_sheet("Ranking")
    ws2.freeze_panes = "A3"

    ws2.merge_cells("A1:H1")
    r1 = ws2["A1"]
    r1.value     = "TOP-RANKING – sortiert nach Modell-Rendite"
    r1.font      = Font(bold=True, color="FFFFFF", name="Arial", size=12)
    r1.fill      = PatternFill("solid", fgColor=C_TITLE_BG)
    r1.alignment = Alignment(horizontal="center", vertical="center")
    ws2.row_dimensions[1].height = 25

    rank_headers = [("RANG",8),("TICKER",12),("RENDITE %",12),("B&H %",12),
                    ("VORTEIL %",12),("TREFFERQUOTE",14),("PROFIT FACTOR",14),("STATUS",14)]
    for col, (h, w) in enumerate(rank_headers, 1):
        hdr_cell(ws2, 2, col, h, w)

    sorted_ok = sorted(ok_results, key=lambda x: x["rendite"], reverse=True)
    for i, r in enumerate(sorted_ok, 1):
        row_i = i + 2
        ws2.row_dimensions[row_i].height = 20
        data_cell(ws2, row_i, 1, i, bold=(i<=3))
        data_cell(ws2, row_i, 2, r["ticker"], bold=True, align="left")
        data_cell(ws2, row_i, 3, r["rendite"])
        data_cell(ws2, row_i, 4, r["bah_rendite"])
        data_cell(ws2, row_i, 5, r["vorteil"])
        data_cell(ws2, row_i, 6, r["trefferquote"])
        data_cell(ws2, row_i, 7, r["profit_factor"])

        if r["rendite"] > 5 and r["profit_factor"] > 1.2:
            s, bg, fg = "⭐ SEHR GUT", C_GOOD_BG, C_GOOD_FG
        elif r["rendite"] > 0:
            s, bg, fg = "✓ GUT",      C_GOOD_BG, C_GOOD_FG
        elif r["rendite"] > -10:
            s, bg, fg = "~ NEUTRAL",  C_MID_BG,  C_MID_FG
        else:
            s, bg, fg = "✗ SCHLECHT", C_BAD_BG,  C_BAD_FG

        sc = ws2.cell(row=row_i, column=8, value=s)
        sc.font = Font(name="Arial", size=10, bold=True, color=fg)
        sc.fill = PatternFill("solid", fgColor=bg)
        sc.alignment = Alignment(horizontal="center", vertical="center")
        sc.border = border

        color_cell(ws2, row_i, 3, r["rendite"])
        color_cell(ws2, row_i, 5, r["vorteil"])

    # Speichern
    pfad = os.path.join(LOG_ORDNER, f"multi_backtest_{datetime.today().strftime('%Y%m%d_%H%M')}.xlsx")
    wb.save(pfad)
    return pfad


@app.route("/api/multi_backtest", methods=["POST"])
def run_multi_backtest():
    """Führt Backtest für mehrere Aktien durch und erstellt Excel-Report."""
    try:
        data    = request.json
        if not data:
            return jsonify({"error": "Keine Daten empfangen"}), 400

        tickers = [t.strip().upper() for t in data.get("tickers", []) if t.strip()]

        if not tickers:
            return jsonify({"error": "Keine Ticker angegeben"}), 400
        if len(tickers) > 50:
            return jsonify({"error": "Maximal 50 Aktien pro Test"}), 400

        params = {
            "vorausschau":        data.get("vorausschau", 3),
            "ziel_rendite":       data.get("ziel_rendite", 0.01),
            "konfidenz":          data.get("konfidenz", 0.55),
            "startkapital":       data.get("startkapital", 1000),
            "transaktionskosten": data.get("transaktionskosten", 0.001),
            "positions_modus":    data.get("positions_modus", "voll"),
            "positions_pct":      data.get("positions_pct", 100),
            "sl_modus":           data.get("sl_modus", "kein"),
            "sl_pct":             data.get("sl_pct", 2.0),
            "tp_aktiv":           data.get("tp_aktiv", False),
            "tp_pct":             data.get("tp_pct", 4.0),
        }

        ergebnisse = []
        for ticker in tickers:
            ergebnis = run_single_backtest(ticker, params)
            ergebnisse.append(ergebnis)

        # Excel erstellen
        try:
            excel_pfad  = erstelle_excel(ergebnisse, params)
            excel_datei = os.path.basename(excel_pfad)
        except Exception as ex:
            import traceback
            excel_datei = None
            print("Excel-Fehler:", traceback.format_exc())

        ok        = [r for r in ergebnisse if not r.get("fehler")]
        fehler    = [r for r in ergebnisse if r.get("fehler")]
        beste     = max(ok, key=lambda x: x["rendite"]) if ok else None

        return jsonify({
            "ergebnisse":    ergebnisse,
            "excel_datei":   excel_datei,
            "anzahl_ok":     int(len(ok)),
            "anzahl_fehler": int(len(fehler)),
            "avg_rendite":   round(float(sum(r["rendite"] for r in ok) / len(ok)), 2) if ok else 0,
            "avg_tq":        round(float(sum(r["trefferquote"] for r in ok) / len(ok)), 1) if ok else 0,
            "beste":         beste["ticker"] if beste else None,
            "beste_rendite": float(beste["rendite"]) if beste else None,
        })

    except Exception as e:
        import traceback
        print("MULTI-BACKTEST FEHLER:", traceback.format_exc())
        return jsonify({"error": str(e), "detail": traceback.format_exc()}), 500


@app.route("/download/<filename>")
def download_file(filename):
    """Ermöglicht den Download von erstellten Dateien."""
    return send_from_directory(LOG_ORDNER, filename, as_attachment=True)

if __name__ == "__main__":
    print("\n" + "=" * 50)
    print("  KI-Trading-System – Web UI")
    print("  Starte Server...")
    print("  Öffne im Browser: http://localhost:5000")
    print("=" * 50 + "\n")
    app.run(debug=False, port=5000, threaded=True)

if __name__ == "__main__":
    print("\n" + "=" * 50)
    print("  KI-Trading-System – Web UI")
    print("  Starte Server...")
    print("  Öffne im Browser: http://localhost:5000")
    print("=" * 50 + "\n")
    app.run(debug=False, port=5000, threaded=True)
