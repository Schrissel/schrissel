# ============================================================
#  📈 KI-Trading-System – Universelles DAX-Modell v2.0
#  ✅ Trainiert auf allen 30 DAX-Aktien gleichzeitig
#  ✅ NEU: Mehr Features (Saisonalität, Kurs-Muster, Makro)
#  ✅ NEU: Konfidenz-Filter (nur starke Signale)
#  ✅ NEU: Dreistufige Signalstärke (STARK / SCHWACH / NEIN)
#  ✅ Täglicher automatischer Scan aller Aktien
#  ✅ Ranking: Beste Kaufsignale oben
#  ✅ Ergebnisse als CSV gespeichert
# ============================================================
#
#  Installation (einmalig im Terminal):
#  pip install yfinance pandas_ta xgboost scikit-learn matplotlib joblib
#
# ============================================================

import os
import joblib
import warnings
import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from xgboost import XGBClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

# ============================================================
# ⚙️  EINSTELLUNGEN
# ============================================================

START_DATE       = "2015-01-01"
ZIEL_RENDITE     = 0.01
NEU_TRAINIEREN   = True

# 🎯 KONFIDENZ-FILTER
SCHWELLE_STARK   = 0.65   # >= 65% → STARKES Kaufsignal  🟢
SCHWELLE_SCHWACH = 0.55   # >= 55% → SCHWACHES Kaufsignal 🟡
                          #  < 55% → NICHT KAUFEN         🔴

BASIS_ORDNER   = "."
DATEN_ORDNER   = f"{BASIS_ORDNER}/daten"
MODELL_ORDNER  = f"{BASIS_ORDNER}/modelle"
LOG_ORDNER     = f"{BASIS_ORDNER}/ergebnisse"

MODELL_PFAD    = f"{MODELL_ORDNER}/dax_universal_modell_v2.pkl"
SCALER_PFAD    = f"{MODELL_ORDNER}/dax_universal_scaler_v2.pkl"
SCAN_LOG_PFAD  = f"{LOG_ORDNER}/dax_daily_scan.csv"

# ============================================================
# 🇩🇪  ALLE 30 DAX-AKTIEN
# ============================================================

DAX_AKTIEN = {
    "Adidas":               "ADS.DE",
    "Airbus":               "AIR.DE",
    "Allianz":              "ALV.DE",
    "BASF":                 "BAS.DE",
    "Bayer":                "BAYN.DE",
    "Beiersdorf":           "BEI.DE",
    "BMW":                  "BMW.DE",
    "Brenntag":             "BNR.DE",
    "Commerzbank":          "CBK.DE",
    "Continental":          "CON.DE",
    "Covestro":             "1COV.DE",
    "Daimler Truck":        "DTG.DE",
    "Deutsche Bank":        "DBK.DE",
    "Deutsche Boerse":      "DB1.DE",
    "Deutsche Post":        "DHL.DE",
    "Deutsche Telekom":     "DTE.DE",
    "E.ON":                 "EOAN.DE",
    "Fresenius":            "FRE.DE",
    "Hannover Rueck":       "HNR1.DE",
    "Heidelberg Materials": "HEIG.DE",
    "Henkel":               "HENKG.DE",
    "Infineon":             "IFX.DE",
    "Mercedes-Benz":        "MBG.DE",
    "Merck":                "MRK.DE",
    "MTU Aero Engines":     "MTX.DE",
    "Muenchener Rueck":     "MUV2.DE",
    "RWE":                  "RWE.DE",
    "SAP":                  "SAP.DE",
    "Siemens":              "SIE.DE",
    "Volkswagen":           "VOW3.DE",
}

FEATURES = [
    # Trend
    "SMA_20", "SMA_50", "EMA_12",
    "Abstand_SMA20", "Abstand_SMA50", "SMA_Kreuz",
    # Momentum
    "RSI", "MACD", "MACD_Signal", "RSI_Trend",
    # Volatilitaet
    "BB_Width", "ATR_norm", "BB_Position",
    # Volumen
    "Volume_Ratio", "Volume_Trend",
    # Renditen
    "Return_1d", "Return_5d", "Return_20d", "Return_60d",
    # Kurs-Muster
    "Higher_High", "Higher_Low", "Gap_Up", "Kerze_Groesse",
    # Saisonalitaet
    "Wochentag", "Monat", "Quartal",
]

for ordner in [DATEN_ORDNER, MODELL_ORDNER, LOG_ORDNER]:
    os.makedirs(ordner, exist_ok=True)

# ============================================================
# 📥  DATEN LADEN
# ============================================================

def lade_aktie(name, ticker):
    heute = datetime.today().strftime("%Y-%m-%d")
    pfad  = f"{DATEN_ORDNER}/{ticker.replace('.', '_')}.csv"
    try:
        if os.path.exists(pfad):
            df = pd.read_csv(pfad, index_col="Date", parse_dates=True)
            naechster = (df.index[-1] + timedelta(days=1)).strftime("%Y-%m-%d")
            if naechster <= heute:
                neue = yf.download(ticker, start=naechster, end=heute,
                                   auto_adjust=True, progress=False)
                if not neue.empty:
                    neue.columns = neue.columns.droplevel(1) if isinstance(neue.columns, pd.MultiIndex) else neue.columns
                    df = pd.concat([df, neue])
                    df = df[~df.index.duplicated(keep="last")]
                    df.to_csv(pfad)
        else:
            df = yf.download(ticker, start=START_DATE, end=heute,
                             auto_adjust=True, progress=False)
            if df.empty:
                return None
            df.columns = df.columns.droplevel(1) if isinstance(df.columns, pd.MultiIndex) else df.columns
            df.to_csv(pfad)
        return df if len(df) > 100 else None
    except Exception as e:
        print(f"   Fehler bei {name} ({ticker}): {e}")
        return None


def lade_alle_dax_daten():
    print("Lade Kursdaten fuer alle 30 DAX-Aktien...")
    print("   (Erstmalig kann das 2-3 Minuten dauern)\n")
    alle_daten = {}
    for name, ticker in DAX_AKTIEN.items():
        df = lade_aktie(name, ticker)
        if df is not None:
            alle_daten[ticker] = (name, df)
            print(f"   OK  {name:25s} ({ticker}) - {len(df)} Tage")
        else:
            print(f"   FEHLER {name:25s} ({ticker}) - Keine Daten")
    print(f"\n{len(alle_daten)}/30 Aktien geladen!\n")
    return alle_daten

# ============================================================
# 📊  INDIKATOREN
# ============================================================

def berechne_indikatoren(df, ticker=""):
    try:
        df = df.copy()

        df["SMA_20"] = ta.sma(df["Close"], length=20)
        df["SMA_50"] = ta.sma(df["Close"], length=50)
        df["EMA_12"] = ta.ema(df["Close"], length=12)
        df["Abstand_SMA20"] = (df["Close"] - df["SMA_20"]) / df["SMA_20"]
        df["Abstand_SMA50"] = (df["Close"] - df["SMA_50"]) / df["SMA_50"]
        df["SMA_Kreuz"] = (df["SMA_20"] > df["SMA_50"]).astype(int)

        df["RSI"] = ta.rsi(df["Close"], length=14)
        df["RSI_Trend"] = df["RSI"] - df["RSI"].shift(3)

        macd = ta.macd(df["Close"])
        macd_col   = [c for c in macd.columns if c.startswith("MACD_")][0]
        signal_col = [c for c in macd.columns if c.startswith("MACDs_")][0]
        df["MACD"]        = macd[macd_col]
        df["MACD_Signal"] = macd[signal_col]

        bb = ta.bbands(df["Close"], length=20)
        bb_upper = [c for c in bb.columns if c.startswith("BBU")][0]
        bb_lower = [c for c in bb.columns if c.startswith("BBL")][0]
        df["BB_Width"]    = (bb[bb_upper] - bb[bb_lower]) / df["Close"]
        df["BB_Position"] = (df["Close"] - bb[bb_lower]) / (bb[bb_upper] - bb[bb_lower])

        atr = ta.atr(df["High"], df["Low"], df["Close"], length=14)
        df["ATR_norm"] = atr / df["Close"]

        df["Volume_SMA"]   = ta.sma(df["Volume"], length=20)
        df["Volume_Ratio"] = df["Volume"] / df["Volume_SMA"]
        df["Volume_Trend"] = (df["Volume"] > df["Volume"].shift(1)).astype(int)

        df["Return_1d"]  = df["Close"].pct_change(1)
        df["Return_5d"]  = df["Close"].pct_change(5)
        df["Return_20d"] = df["Close"].pct_change(20)
        df["Return_60d"] = df["Close"].pct_change(60)

        df["Higher_High"]   = (df["High"] > df["High"].shift(1)).astype(int)
        df["Higher_Low"]    = (df["Low"] > df["Low"].shift(1)).astype(int)
        df["Gap_Up"]        = (df["Open"] > df["Close"].shift(1)).astype(int)
        df["Kerze_Groesse"] = (df["High"] - df["Low"]) / df["Close"]

        df["Wochentag"] = df.index.dayofweek
        df["Monat"]     = df.index.month
        df["Quartal"]   = df.index.quarter

        df["Target"] = (df["Close"].shift(-1) / df["Close"] - 1 > ZIEL_RENDITE).astype(int)

        df.dropna(inplace=True)
        return df
    except Exception as e:
        print(f"   Indikator-Fehler bei {ticker}: {e}")
        return None


def bereite_trainingsdaten_vor(alle_daten):
    print("Berechne Indikatoren fuer alle Aktien...")
    alle_frames = []
    for ticker, (name, df) in alle_daten.items():
        df_ind = berechne_indikatoren(df, ticker)
        if df_ind is not None and len(df_ind) > 50:
            alle_frames.append(df_ind[FEATURES + ["Target"]])
            print(f"   OK  {name:25s} - {len(df_ind)} Datenpunkte")
    gesamt_df = pd.concat(alle_frames, ignore_index=True)
    gesamt_df.dropna(inplace=True)
    print(f"\nGesamtdatensatz: {len(gesamt_df):,} Datenpunkte | {len(FEATURES)} Features")
    print(f"Kaufsignale: {gesamt_df['Target'].sum():,} ({gesamt_df['Target'].mean()*100:.1f}%)\n")
    return gesamt_df

# ============================================================
# 🤖  MODELL
# ============================================================

def trainiere_oder_lade_modell(gesamt_df):
    modell_existiert = os.path.exists(MODELL_PFAD) and os.path.exists(SCALER_PFAD)
    if modell_existiert and not NEU_TRAINIEREN:
        print("Lade gespeichertes Modell v2...")
        model  = joblib.load(MODELL_PFAD)
        scaler = joblib.load(SCALER_PFAD)
        print(f"Modell geladen: {MODELL_PFAD}\n")
        return model, scaler

    print("Trainiere XGBoost-Modell v2 (kann 5-15 Min dauern)...\n")
    X = gesamt_df[FEATURES]
    y = gesamt_df["Target"]

    scaler = StandardScaler()
    tscv   = TimeSeriesSplit(n_splits=5)
    alle_preds, alle_true = [], []

    for fold, (train_idx, test_idx) in enumerate(tscv.split(X)):
        X_train = scaler.fit_transform(X.iloc[train_idx])
        X_test  = scaler.transform(X.iloc[test_idx])
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
        model = XGBClassifier(
            n_estimators=500, max_depth=5, learning_rate=0.03,
            subsample=0.8, colsample_bytree=0.8, min_child_weight=10,
            eval_metric="logloss", random_state=42, verbosity=0, n_jobs=-1
        )
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        alle_preds.extend(preds)
        alle_true.extend(y_test)
        print(f"   Fold {fold+1}/5: Accuracy = {accuracy_score(y_test, preds)*100:.1f}%")

    print(f"\nGesamt-Accuracy: {accuracy_score(alle_true, alle_preds)*100:.1f}%")
    print(classification_report(alle_true, alle_preds, target_names=["Kein Signal", "Kaufsignal"]))

    X_all = scaler.fit_transform(X)
    model.fit(X_all, y)
    joblib.dump(model, MODELL_PFAD)
    joblib.dump(scaler, SCALER_PFAD)
    print(f"Modell gespeichert: {MODELL_PFAD}")

    importances = pd.Series(model.feature_importances_, index=FEATURES).sort_values()
    plt.figure(figsize=(12, 8))
    importances.plot(kind="barh", color="steelblue")
    plt.title("Feature Importance - DAX Universal Modell v2", fontsize=14)
    plt.tight_layout()
    plt.savefig(f"{LOG_ORDNER}/dax_feature_importance_v2.png", dpi=150)
    plt.close()
    print("Feature-Chart gespeichert!\n")
    return model, scaler

# ============================================================
# 🔍  SCAN MIT KONFIDENZ-FILTER
# ============================================================

def signal_staerke(wkeit):
    if wkeit >= SCHWELLE_STARK:
        return "STARK KAUFEN",   "STARK"
    elif wkeit >= SCHWELLE_SCHWACH:
        return "SCHWACH KAUFEN", "SCHWACH"
    else:
        return "NICHT KAUFEN",   "NEIN"


def scanne_alle_aktien(alle_daten, model, scaler):
    print("Scanne alle DAX-Aktien...\n")
    heute   = datetime.today().strftime("%d.%m.%Y")
    results = []
    for ticker, (name, df) in alle_daten.items():
        try:
            df_ind = berechne_indikatoren(df, ticker)
            if df_ind is None or len(df_ind) < 10:
                continue
            letzter        = df_ind[FEATURES].iloc[[-1]]
            letzter_scaled = scaler.transform(letzter)
            wkeit          = model.predict_proba(letzter_scaled)[0][1]
            signal, stufe  = signal_staerke(wkeit)
            kurs   = df_ind["Close"].iloc[-1]
            rsi    = df_ind["RSI"].iloc[-1]
            ret_1d = df_ind["Return_1d"].iloc[-1] * 100
            sma_kr = df_ind["SMA_Kreuz"].iloc[-1]
            bb_pos = df_ind["BB_Position"].iloc[-1]
            results.append({
                "Datum":              heute,
                "Aktie":              name,
                "Ticker":             ticker,
                "Kurs (EUR)":         round(kurs, 2),
                "Signal":             signal,
                "Staerke":            stufe,
                "Wahrscheinlichkeit": round(wkeit * 100, 1),
                "RSI":                round(rsi, 1),
                "BB Position":        round(bb_pos, 2),
                "Goldenes Kreuz":     "JA" if sma_kr == 1 else "NEIN",
                "Rendite gestern %":  round(ret_1d, 2),
            })
        except Exception as e:
            print(f"   Fehler bei {name}: {e}")

    results_df = pd.DataFrame(results)
    signal_order = {"STARK KAUFEN": 0, "SCHWACH KAUFEN": 1, "NICHT KAUFEN": 2}
    results_df["Sort"] = results_df["Signal"].map(signal_order)
    results_df = results_df.sort_values(["Sort", "Wahrscheinlichkeit"], ascending=[True, False])
    results_df = results_df.drop(columns=["Sort"])
    return results_df


def zeige_scan_ergebnis(results_df):
    stark   = results_df[results_df["Signal"] == "STARK KAUFEN"]
    schwach = results_df[results_df["Signal"] == "SCHWACH KAUFEN"]
    nein    = results_df[results_df["Signal"] == "NICHT KAUFEN"]

    print("=" * 70)
    print(f"  DAX TAGES-SCAN v2 - {datetime.today().strftime('%d.%m.%Y %H:%M')}")
    print(f"  Konfidenz-Filter: Stark >= {SCHWELLE_STARK*100:.0f}% | Schwach >= {SCHWELLE_SCHWACH*100:.0f}%")
    print("=" * 70)

    print(f"\n[GRUEN] STARKE KAUFSIGNALE >= {SCHWELLE_STARK*100:.0f}% ({len(stark)} Aktien)\n")
    if len(stark) > 0:
        print(f"  {'Aktie':<22} {'Kurs':>9} {'Wkeit':>7} {'RSI':>6} {'GK':>5} {'Rendite':>9}")
        print(f"  {'-'*62}")
        for _, row in stark.iterrows():
            print(f"  {row['Aktie']:<22} {row['Kurs (EUR)']:>8.2f}E "
                  f"{row['Wahrscheinlichkeit']:>6.1f}% "
                  f"{row['RSI']:>6.1f} "
                  f"{row['Goldenes Kreuz']:>5} "
                  f"{row['Rendite gestern %']:>+8.2f}%")
    else:
        print("  Keine starken Kaufsignale heute.")

    print(f"\n[GELB] SCHWACHE KAUFSIGNALE {SCHWELLE_SCHWACH*100:.0f}-{SCHWELLE_STARK*100:.0f}% ({len(schwach)} Aktien)\n")
    if len(schwach) > 0:
        print(f"  {'Aktie':<22} {'Kurs':>9} {'Wkeit':>7} {'RSI':>6} {'GK':>5} {'Rendite':>9}")
        print(f"  {'-'*62}")
        for _, row in schwach.iterrows():
            print(f"  {row['Aktie']:<22} {row['Kurs (EUR)']:>8.2f}E "
                  f"{row['Wahrscheinlichkeit']:>6.1f}% "
                  f"{row['RSI']:>6.1f} "
                  f"{row['Goldenes Kreuz']:>5} "
                  f"{row['Rendite gestern %']:>+8.2f}%")
    else:
        print("  Keine schwachen Kaufsignale heute.")

    print(f"\n[ROT] NICHT KAUFEN ({len(nein)} Aktien)\n")
    print(f"  {'Aktie':<22} {'Kurs':>9} {'Wkeit':>7} {'RSI':>6} {'Rendite':>9}")
    print(f"  {'-'*57}")
    for _, row in nein.iterrows():
        print(f"  {row['Aktie']:<22} {row['Kurs (EUR)']:>8.2f}E "
              f"{row['Wahrscheinlichkeit']:>6.1f}% "
              f"{row['RSI']:>6.1f} "
              f"{row['Rendite gestern %']:>+8.2f}%")

    print("\n" + "=" * 70)
    print("  WICHTIG: Kein Finanzrat - nur zum Lernen & Papier-Trading!")
    print("=" * 70)


def speichere_scan_ergebnis(results_df):
    heute = datetime.today().strftime("%d.%m.%Y")
    if os.path.exists(SCAN_LOG_PFAD):
        log = pd.read_csv(SCAN_LOG_PFAD)
        if heute not in log["Datum"].values:
            log = pd.concat([log, results_df], ignore_index=True)
            log.to_csv(SCAN_LOG_PFAD, index=False)
            print(f"\nScan gespeichert: {SCAN_LOG_PFAD}")
        else:
            print(f"\nScan fuer heute bereits gespeichert.")
    else:
        results_df.to_csv(SCAN_LOG_PFAD, index=False)
        print(f"\nNeues Scan-Protokoll erstellt: {SCAN_LOG_PFAD}")

# ============================================================
# HAUPTPROGRAMM
# ============================================================

if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("  KI-Trading-System - DAX Universal Modell v2.0")
    print(f"  {datetime.today().strftime('%d.%m.%Y %H:%M:%S')}")
    print("=" * 70 + "\n")

    alle_daten = lade_alle_dax_daten()

    modell_existiert = os.path.exists(MODELL_PFAD) and os.path.exists(SCALER_PFAD)
    if not modell_existiert or NEU_TRAINIEREN:
        gesamt_df = bereite_trainingsdaten_vor(alle_daten)
        model, scaler = trainiere_oder_lade_modell(gesamt_df)
    else:
        model, scaler = trainiere_oder_lade_modell(None)

    results_df = scanne_alle_aktien(alle_daten, model, scaler)
    zeige_scan_ergebnis(results_df)
    speichere_scan_ergebnis(results_df)

    print("\nFertig! Dateien gespeichert in:")
    print(f"   daten/      - {len(DAX_AKTIEN)} CSV-Dateien")
    print(f"   modelle/    - dax_universal_modell_v2.pkl")
    print(f"   ergebnisse/ - dax_daily_scan.csv\n")
