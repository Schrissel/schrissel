# ============================================================
#  📈 KI-Trading-System – Finaler Code v2.0
#  ✅ CSV speichern & automatisch aktualisieren
#  ✅ Modell speichern & laden
#  ✅ Tägliches Signal mit Erklärung
#  ✅ Ergebnisse protokollieren
# ============================================================
#
#  Installation (einmalig im Terminal):
#  pip install yfinance pandas_ta xgboost scikit-learn matplotlib joblib
#
# ============================================================

import os
import joblib
import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from xgboost import XGBClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler

# ============================================================
# ⚙️  EINSTELLUNGEN – hier kannst du alles anpassen!
# ============================================================

TICKER          = "BAS.DE"          # Aktie (z.B. "MSFT", "TSLA", "SAP.DE")
START_DATE      = "2018-01-01"    # Startdatum für historische Daten
ZIEL_RENDITE    = 0.01            # Kaufsignal wenn Aktie > 1% steigt
NEU_TRAINIEREN  = False           # True = Modell immer neu trainieren
                                  # False = gespeichertes Modell laden (schneller)

# Ordner-Struktur – passe die Pfade nach Bedarf an
# Windows Beispiel: "C:/Users/DeinName/Dokumente/trading_system/daten"
# Mac Beispiel:     "/Users/DeinName/Dokumente/trading_system/daten"
BASIS_ORDNER    = "trading_system"
DATEN_ORDNER    = f"{BASIS_ORDNER}/daten"
MODELL_ORDNER   = f"{BASIS_ORDNER}/modelle"
LOG_ORDNER      = f"{BASIS_ORDNER}/ergebnisse"

# ============================================================
# 🛠️  SETUP – Ordner erstellen
# ============================================================

for ordner in [DATEN_ORDNER, MODELL_ORDNER, LOG_ORDNER]:
    os.makedirs(ordner, exist_ok=True)

DATEN_PFAD  = f"{DATEN_ORDNER}/{TICKER}.csv"
MODELL_PFAD = f"{MODELL_ORDNER}/{TICKER}_modell.pkl"
SCALER_PFAD = f"{MODELL_ORDNER}/{TICKER}_scaler.pkl"
LOG_PFAD    = f"{LOG_ORDNER}/{TICKER}_signale.csv"

FEATURES = [
    "SMA_20", "SMA_50", "EMA_12",
    "RSI", "MACD", "MACD_Signal",
    "BB_Width", "ATR",
    "Volume_Ratio",
    "Return_1d", "Return_5d", "Return_20d"
]

# ============================================================
# 📥  SCHRITT 1: Daten laden & aktualisieren
# ============================================================

def lade_daten(ticker, start_date):
    """
    Lädt Kursdaten: lokal wenn vorhanden, sonst von Yahoo Finance.
    Ergänzt automatisch fehlende Tage seit dem letzten Download.
    """
    heute = datetime.today().strftime("%Y-%m-%d")

    if os.path.exists(DATEN_PFAD):
        print(f"📂 Lokale Daten gefunden: {DATEN_PFAD}")
        df = pd.read_csv(DATEN_PFAD, index_col="Date", parse_dates=True)

        letztes_datum = df.index[-1].strftime("%Y-%m-%d")
        print(f"   Letzte gespeicherte Daten: {letztes_datum}")

        # Prüfen ob neue Daten verfügbar sind
        naechster_tag = (df.index[-1] + timedelta(days=1)).strftime("%Y-%m-%d")
        if naechster_tag <= heute:
            print(f"🌐 Lade neue Daten nach: {naechster_tag} bis {heute}")
            neue_daten = yf.download(ticker, start=naechster_tag, end=heute, auto_adjust=True, progress=False)

            if not neue_daten.empty:
                neue_daten.columns = neue_daten.columns.droplevel(1) if isinstance(neue_daten.columns, pd.MultiIndex) else neue_daten.columns
                df = pd.concat([df, neue_daten])
                df = df[~df.index.duplicated(keep="last")]  # Duplikate entfernen
                df.to_csv(DATEN_PFAD)
                print(f"✅ {len(neue_daten)} neue Tage hinzugefügt & gespeichert!")
            else:
                print("ℹ️  Keine neuen Daten verfügbar (Börse heute geschlossen?).")
        else:
            print("✅ Daten sind bereits aktuell!")

    else:
        print(f"🌐 Kein lokaler Datensatz – lade alles von Yahoo Finance...")
        df = yf.download(ticker, start=start_date, end=heute, auto_adjust=True, progress=False)
        df.columns = df.columns.droplevel(1) if isinstance(df.columns, pd.MultiIndex) else df.columns
        df.to_csv(DATEN_PFAD)
        print(f"✅ {len(df)} Handelstage gespeichert unter: {DATEN_PFAD}")

    return df

# ============================================================
# 📊  SCHRITT 2: Indikatoren berechnen
# ============================================================

def berechne_indikatoren(df):
    """Berechnet alle technischen Indikatoren und gibt den DataFrame zurück."""
    print("\n📊 Berechne technische Indikatoren...")

    df["SMA_20"]       = ta.sma(df["Close"], length=20)
    df["SMA_50"]       = ta.sma(df["Close"], length=50)
    df["EMA_12"]       = ta.ema(df["Close"], length=12)
    df["RSI"]          = ta.rsi(df["Close"], length=14)

    macd = ta.macd(df["Close"])
    # Spaltenname automatisch erkennen
    macd_col   = [c for c in macd.columns if c.startswith("MACD_")][0]
    signal_col = [c for c in macd.columns if c.startswith("MACDs_")][0]
    df["MACD"]         = macd[macd_col]
    df["MACD_Signal"]  = macd[signal_col]

    bb = ta.bbands(df["Close"], length=20)
    # Spaltenname automatisch erkennen (unterschiedlich je nach pandas_ta Version)
    bb_upper_col = [c for c in bb.columns if c.startswith("BBU")][0]
    bb_lower_col = [c for c in bb.columns if c.startswith("BBL")][0]
    df["BB_Upper"]     = bb[bb_upper_col]
    df["BB_Lower"]     = bb[bb_lower_col]
    df["BB_Width"]     = (df["BB_Upper"] - df["BB_Lower"]) / df["Close"]

    df["ATR"]          = ta.atr(df["High"], df["Low"], df["Close"], length=14)
    df["Volume_SMA"]   = ta.sma(df["Volume"], length=20)
    df["Volume_Ratio"] = df["Volume"] / df["Volume_SMA"]
    df["Return_1d"]    = df["Close"].pct_change(1)
    df["Return_5d"]    = df["Close"].pct_change(5)
    df["Return_20d"]   = df["Close"].pct_change(20)

    # Zielvariable: Steigt die Aktie morgen um mehr als ZIEL_RENDITE?
    df["Target"] = (df["Close"].shift(-1) / df["Close"] - 1 > ZIEL_RENDITE).astype(int)

    df.dropna(inplace=True)
    print(f"✅ Indikatoren berechnet! ({len(df)} Handelstage verfügbar)")
    return df

# ============================================================
# 🤖  SCHRITT 3: Modell trainieren oder laden
# ============================================================

def trainiere_oder_lade_modell(df):
    """
    Lädt das gespeicherte Modell wenn vorhanden (und NEU_TRAINIEREN=False).
    Sonst wird das Modell neu trainiert und gespeichert.
    """
    modell_existiert = os.path.exists(MODELL_PFAD) and os.path.exists(SCALER_PFAD)

    if modell_existiert and not NEU_TRAINIEREN:
        print("\n📦 Lade gespeichertes Modell...")
        model  = joblib.load(MODELL_PFAD)
        scaler = joblib.load(SCALER_PFAD)
        print(f"✅ Modell geladen: {MODELL_PFAD}")
        return model, scaler

    # Neu trainieren
    print("\n🤖 Trainiere XGBoost-Modell (Walk-Forward Validation)...")
    X = df[FEATURES]
    y = df["Target"]

    tscv = TimeSeriesSplit(n_splits=5)
    scaler = StandardScaler()
    alle_predictions, alle_true = [], []

    for fold, (train_idx, test_idx) in enumerate(tscv.split(X)):
        X_train = scaler.fit_transform(X.iloc[train_idx])
        X_test  = scaler.transform(X.iloc[test_idx])
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        model = XGBClassifier(
            n_estimators=200, max_depth=4, learning_rate=0.05,
            subsample=0.8, colsample_bytree=0.8,
            eval_metric="logloss", random_state=42, verbosity=0
        )
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        alle_predictions.extend(preds)
        alle_true.extend(y_test)
        print(f"   Fold {fold+1}/5: Accuracy = {accuracy_score(y_test, preds)*100:.1f}%")

    gesamt_acc = accuracy_score(alle_true, alle_predictions)
    print(f"\n🏆 Gesamt-Accuracy: {gesamt_acc*100:.1f}%")
    print(classification_report(alle_true, alle_predictions,
                                 target_names=["Kein Signal", "Kaufsignal"]))

    # Finales Modell auf allen Daten trainieren
    X_all = scaler.fit_transform(X)
    model.fit(X_all, y)

    # Speichern
    joblib.dump(model, MODELL_PFAD)
    joblib.dump(scaler, SCALER_PFAD)
    print(f"💾 Modell gespeichert: {MODELL_PFAD}")

    # Feature Importance Chart
    importances = pd.Series(model.feature_importances_, index=FEATURES).sort_values()
    plt.figure(figsize=(10, 6))
    importances.plot(kind="barh", color="steelblue")
    plt.title(f"Feature Importance – {TICKER}", fontsize=14)
    plt.xlabel("Wichtigkeit")
    plt.tight_layout()
    chart_pfad = f"{LOG_ORDNER}/{TICKER}_feature_importance.png"
    plt.savefig(chart_pfad, dpi=150)
    plt.close()
    print(f"📊 Feature-Importance-Chart gespeichert: {chart_pfad}")

    return model, scaler

# ============================================================
# 🔮  SCHRITT 4: Signal für heute generieren
# ============================================================

def generiere_signal(df, model, scaler):
    """Generiert das aktuelle Kaufsignal und zeigt eine Erklärung."""
    letzter_tag   = df[FEATURES].iloc[[-1]]
    letzter_scaled = scaler.transform(letzter_tag)

    signal        = model.predict(letzter_scaled)[0]
    wahrscheinlichkeit = model.predict_proba(letzter_scaled)[0][1]
    letzter_kurs  = df["Close"].iloc[-1]
    datum         = df.index[-1].strftime("%d.%m.%Y")
    rsi_wert      = df["RSI"].iloc[-1]
    macd_wert     = df["MACD"].iloc[-1]
    vol_ratio     = df["Volume_Ratio"].iloc[-1]

    print("\n" + "="*55)
    print(f"  🔮 TRADING SIGNAL – {TICKER} – {datum}")
    print("="*55)
    print(f"  Letzter Kurs:       ${letzter_kurs:.2f}")
    print(f"  Signal:             {'🟢 KAUFEN' if signal == 1 else '🔴 NICHT KAUFEN'}")
    print(f"  Wahrscheinlichkeit: {wahrscheinlichkeit*100:.1f}%")
    print("-"*55)
    print(f"  RSI (14):           {rsi_wert:.1f}  {'⚠️  überkauft' if rsi_wert > 70 else '✅ normal' if rsi_wert > 30 else '⚠️  überverkauft'}")
    print(f"  MACD:               {macd_wert:.4f}  {'📈 positiv' if macd_wert > 0 else '📉 negativ'}")
    print(f"  Volumen-Verhältnis: {vol_ratio:.2f}x  {'📢 erhöht' if vol_ratio > 1.2 else '😴 normal'}")
    print("="*55)
    print("  ⚠️  Kein Finanzrat – nur zum Lernen & Papier-Trading!")
    print("="*55)

    return signal, wahrscheinlichkeit, letzter_kurs, datum

# ============================================================
# 📝  SCHRITT 5: Signal protokollieren
# ============================================================

def protokolliere_signal(datum, kurs, signal, wahrscheinlichkeit):
    """Speichert jedes Signal in einer CSV-Datei zur späteren Auswertung."""
    eintrag = pd.DataFrame([{
        "Datum":             datum,
        "Kurs":              round(kurs, 2),
        "Signal":            "KAUFEN" if signal == 1 else "NICHT KAUFEN",
        "Wahrscheinlichkeit": round(wahrscheinlichkeit * 100, 1),
        "Ergebnis":          ""   # kannst du später manuell eintragen: RICHTIG / FALSCH
    }])

    if os.path.exists(LOG_PFAD):
        log = pd.read_csv(LOG_PFAD)
        # Verhindere doppelte Einträge für denselben Tag
        if datum not in log["Datum"].values:
            log = pd.concat([log, eintrag], ignore_index=True)
            log.to_csv(LOG_PFAD, index=False)
            print(f"\n📝 Signal protokolliert: {LOG_PFAD}")
        else:
            print(f"\nℹ️  Signal für {datum} bereits protokolliert.")
    else:
        eintrag.to_csv(LOG_PFAD, index=False)
        print(f"\n📝 Neues Protokoll erstellt: {LOG_PFAD}")

# ============================================================
# ▶️  HAUPTPROGRAMM
# ============================================================

if __name__ == "__main__":
    print("\n" + "="*55)
    print(f"  📈 KI-Trading-System gestartet – {TICKER}")
    print(f"  {datetime.today().strftime('%d.%m.%Y %H:%M:%S')}")
    print("="*55 + "\n")

    # Schritt 1: Daten laden / aktualisieren
    df = lade_daten(TICKER, START_DATE)

    # Schritt 2: Indikatoren berechnen
    df = berechne_indikatoren(df)

    # Schritt 3: Modell laden oder trainieren
    model, scaler = trainiere_oder_lade_modell(df)

    # Schritt 4: Signal generieren
    signal, wkeit, kurs, datum = generiere_signal(df, model, scaler)

    # Schritt 5: Signal speichern
    protokolliere_signal(datum, kurs, signal, wkeit)

    print("\n✅ Fertig! Ordnerstruktur:")
    print(f"   📁 {BASIS_ORDNER}/")
    print(f"      📁 daten/      → {TICKER}.csv")
    print(f"      📁 modelle/    → {TICKER}_modell.pkl")
    print(f"      📁 ergebnisse/ → {TICKER}_signale.csv")